// Screenshot + metrics for one prototype take, identical for every take.
// Usage: node harness/shoot.cjs <take> <port> [--quick]
//   writes proto/<take>/shots/{desk,mob}-<scene>.png, desk-<scene>-clean.png, metrics.json
// --quick: desktop only, hero + desks + contact (for fast iteration).
const { chromium } = require("playwright");
const fs = require("fs");
const path = require("path");
const { serve } = require("./serve.cjs");

const take = process.argv[2];
const port = Number(process.argv[3] || 4100);
const quick = process.argv.includes("--quick");
if (!take) {
  console.error("usage: node harness/shoot.cjs <take> <port> [--quick]");
  process.exit(2);
}
const OUT = path.resolve(__dirname, "..", take, "shots");
fs.mkdirSync(OUT, { recursive: true });

const SCENES = [
  ["hero", 0],
  ["hero-to-desks", 0.14],
  ["desks", 0.28],
  ["straits", 0.52],
  ["straits-to-process", 0.64],
  ["process", 0.76],
  ["contact", 1],
];
const VIEWPORTS = [
  ["desk", { width: 1440, height: 900 }],
  ["mob", { width: 390, height: 844 }],
];

(async () => {
  const server = await serve(port);
  const browser = await chromium.launch({
    args: ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"],
  });
  const metrics = { take, shots: {}, errors: [] };
  const vps = quick ? [VIEWPORTS[0]] : VIEWPORTS;
  const scenes = quick ? SCENES.filter(([id]) => ["hero", "desks", "contact"].includes(id)) : SCENES;
  for (const [tag, viewport] of vps) {
    const ctx = await browser.newContext({ viewport, deviceScaleFactor: 1 });
    const page = await ctx.newPage();
    page.on("console", (m) => {
      if (m.type() === "error" || m.type() === "warning") metrics.errors.push(`[${tag}] ${m.type()}: ${m.text()}`);
    });
    page.on("pageerror", (e) => metrics.errors.push(`[${tag}] pageerror: ${e.message}`));
    const variants = tag === "desk" && !quick ? [["", 1], ["-clean", 0]] : [["", 1]];
    for (const [id, p] of scenes) {
      for (const [suffix, overlay] of variants) {
        if (suffix && id.includes("-to-")) continue;
        const url = `http://127.0.0.1:${port}/harness/index.html?take=${take}&p=${p}&t=12&dpr=1&overlay=${overlay}&q=${tag === "mob" ? "low" : "high"}`;
        const t0 = Date.now();
        await page.goto(url, { waitUntil: "load", timeout: 120000 });
        await page.waitForFunction(() => window.__ready === true, null, { timeout: 120000 });
        const ms = Date.now() - t0;
        const shot = `${tag}-${id}${suffix}.png`;
        await page.screenshot({ path: path.join(OUT, shot) });
        const data = await page.evaluate(() => ({ horizon: window.__horizon, info: window.__info, error: window.__error || null }));
        metrics.shots[shot] = { ms, ...data };
        if (data.error) metrics.errors.push(`[${shot}] ${data.error}`);
      }
    }
    // Relative frame cost in SwiftShader (CPU rasteriser; compare takes, not absolute fps).
    if (!quick || tag === "desk") {
      await page.goto(`http://127.0.0.1:${port}/harness/index.html?take=${take}&p=0.14&t=12&dpr=1&overlay=0&q=${tag === "mob" ? "low" : "high"}`, { waitUntil: "load", timeout: 120000 });
      await page.waitForFunction(() => window.__ready === true, null, { timeout: 120000 });
      metrics[`${tag}FrameMs`] = await page.evaluate(() => {
        const v = window.__voyage;
        if (!v) return null;
        const gl = document.getElementById("c").getContext("webgl2") || document.getElementById("c").getContext("webgl");
        const n = 12;
        const t0 = performance.now();
        for (let i = 0; i < n; i++) {
          v.setTime(12 + i / 30);
          v.setProgress(0.14 + i * 0.002);
          v.renderOnce();
          if (gl) gl.finish();
        }
        return +((performance.now() - t0) / n).toFixed(1);
      });
    }
    await ctx.close();
  }
  // JS weight of the take's own bundle (three included).
  const bundle = path.resolve(__dirname, "..", take, "dist", "app.js");
  if (fs.existsSync(bundle)) metrics.bundleKB = Math.round(fs.statSync(bundle).size / 1024);
  fs.writeFileSync(path.join(OUT, "metrics.json"), JSON.stringify(metrics, null, 2));
  console.log(JSON.stringify({ take, frameMs: { desk: metrics.deskFrameMs, mob: metrics.mobFrameMs }, bundleKB: metrics.bundleKB, errors: metrics.errors.slice(0, 10), shots: Object.keys(metrics.shots).length }, null, 2));
  await browser.close();
  server.close();
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
