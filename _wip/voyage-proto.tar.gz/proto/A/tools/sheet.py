# Compose PNGs into a labelled contact sheet: python3 sheet.py out.png scale file...
import sys
from PIL import Image, ImageDraw
out, scale = sys.argv[1], float(sys.argv[2])
files = sys.argv[3:]
ims = [Image.open(f).convert("RGB") for f in files]
ims = [im.resize((int(im.width * scale), int(im.height * scale)), Image.LANCZOS) for im in ims]
W = sum(im.width for im in ims) + 6 * (len(ims) - 1)
H = max(im.height for im in ims) + 18
sheet = Image.new("RGB", (W, H), (40, 40, 40))
x = 0
d = ImageDraw.Draw(sheet)
for f, im in zip(files, ims):
    sheet.paste(im, (x, 18))
    d.text((x + 4, 3), f.split("/")[-1], fill=(255, 255, 255))
    x += im.width + 6
sheet.save(out)
print(out, sheet.size)
