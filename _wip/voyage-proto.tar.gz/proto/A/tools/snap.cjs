// Iteration helper for take A (not part of the deliverable): renders chosen
// progress points through the shared harness page and writes PNGs to A/work/.
// usage: node A/tools/snap.cjs <port> <spec...>   spec = d:0.28 | m:0.14 | dc:0.5 (c = clean, no overlay)
const { chromium } = require("/opt/node-tools/node_modules/playwright");
const path = require("path");
const fs = require("fs");
const { serve } = require("../../harness/serve.cjs");
const port = Number(process.argv[2]);
const specs = process.argv.slice(3);
const OUT = path.resolve(__dirname, "..", "work");
fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const server = await serve(port);
  const browser = await chromium.launch({ args: ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"] });
  const ctxs = {};
  const errors = [];
  for (const spec of specs) {
    const [tag, pstr, tstr] = spec.split(":");
    const mob = tag.startsWith("m");
    const clean = tag.includes("c");
    const key = mob ? "m" : "d";
    if (!ctxs[key]) {
      ctxs[key] = await browser.newContext({ viewport: mob ? { width: 390, height: 844 } : { width: 1440, height: 900 }, deviceScaleFactor: 1 });
    }
    const page = await ctxs[key].newPage();
    page.on("console", (m) => { if (m.type() === "error" || m.type() === "warning") errors.push(`${spec}: ${m.text().slice(0, 400)}`); });
    page.on("pageerror", (e) => errors.push(`${spec}: pageerror ${e.message}`));
    const t = tstr || "12";
    const url = `http://127.0.0.1:${port}/harness/index.html?take=A&p=${pstr}&t=${t}&dpr=1&overlay=${clean ? 0 : 1}&q=${mob ? "low" : "high"}`;
    const t0 = Date.now();
    await page.goto(url, { waitUntil: "load", timeout: 120000 });
    await page.waitForFunction(() => window.__ready === true, null, { timeout: 120000 });
    const file = path.join(OUT, `${tag}-${pstr}${tstr ? "-t" + tstr : ""}.png`);
    await page.screenshot({ path: file });
    const data = await page.evaluate(() => ({ horizon: window.__horizon, info: window.__info, error: window.__error || null }));
    console.log(spec, Date.now() - t0 + "ms", JSON.stringify(data));
    await page.close();
  }
  if (errors.length) console.log("ERRORS:\n" + errors.slice(0, 20).join("\n"));
  await browser.close();
  server.close();
})().catch((e) => { console.error(e); process.exit(1); });
