import type { CreateVoyage } from "../../contract";
import { createEngine } from "./engine";

export { SCENES as VOYAGE_SCENES } from "../../contract";

/** LEVANTER "Voyage", take A — "Oil on linen". */
export const createVoyage: CreateVoyage = (opts) => createEngine(opts);
