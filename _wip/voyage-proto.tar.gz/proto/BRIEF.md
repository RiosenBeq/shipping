# LEVANTER "Voyage" — three.js scroll-journey background (prototype brief)

`$SP` below = `/tmp/claude-0/-home-user-shipping/d35f7d67-e32f-5d3f-9a0b-c75236b49d34/scratchpad`.
Workspace = `$SP/proto`. You work ONLY inside `$SP/proto/<YOUR_TAKE>/`. Do not edit the repo at
`/home/user/shipping` (read it if useful), the harness, `contract.ts`, or another take's folder.

## 1. Why

The client (LEVANTER — an Istanbul tanker & LPG/ammonia shipbroker, Next.js site) wants the homepage
background redone in the spirit of **gnbshipbrokers.com** ("Green & Black Shipbrokers"), but adapted
to LEVANTER's brand, built with **three.js**, and aesthetically better than the reference.

### What the reference does (study the screenshots — they are the mood board)

- `$SP/shots/desk-h.png`, `desk-tanker-1.png`, `desk-tanker-2.png`, `desk-istanbul.png`,
  `desk-contact.png`, `desk-sharks.png`, `desk-team.png`, `desk-dubai.png`, `desk-darussafaka.png`
  (desktop 1440×900) and `mob-*.png` (390×844). `d-00.png … d-40.png` are frames while scrolling.
- ONE fixed full-screen "stage" sits behind the whole page. Scrolling scrubs a cinematic camera journey
  through painted maritime scenes: harbour + tanker → open sea following the tanker → services over
  the waves → underwater → Istanbul's Bosphorus (mosques, Galata tower, palace, bridge, tanker,
  gulls) → Dubai → sunset beach. Content sits on the scenes with soft radial "scrims" for legibility.
- The imagery is AI-painted video drawn on a WebGL canvas with a shader that adds a **paper/linen print
  texture, film grain and a halftone-dot transition**. Base paper colour `#F2EBDD`, ink `#0B0F0D`.
- Thin **chart-frame hairlines** with "+" crosshairs at the intersections, and a **horizon hairline**
  that tracks the painted horizon of every scene. A left **progress rail** with a little ship marker.
- Big tight sans headlines on a light painted sky (light scenes) and pale text on dark bands (dark scenes).

We keep the IDEA (a living, painted, cinematic sea journey behind the content, chart frame, horizon
line, print texture) and make it LEVANTER's own: our palette, our places, our ships, rendered live
and procedurally with three.js (no video, no external images — a strict CSP allows only same-origin).

## 2. LEVANTER brand

- Palette: navy `#0A1F33`, navy-deep `#051624`, navy-soft `#13304A`, brass `#B8893A`, brass-ink
  `#8A6420`, brass-light `#D9B071`, sand/paper `#F3EFE4`, line `#E4DDCC`, slate `#4A5E6E`,
  fog `#A9B6BF`, page bg `#FBFAF7`. Extra sea tones allowed: teal `#1B4D5C`, deep-sea `#0E3454`,
  foam `#8AA6B0`. Brass is the accent (sun, funnel bands, lights) — use it with restraint.
- Type: serif display (Source Serif 4) for headlines, Manrope body, IBM Plex Mono labels.
- Existing motifs: a chart graticule grid, line-art vessel drawings (`/home/user/shipping/components/site/VesselArt.tsx`).
- Current homepage for context: `/home/user/shipping/docs/screenshots/after/home-desktop.webp`.
- Place: the Istanbul desk sits on the Bosphorus (Beşiktaş). Turkish Straits expertise; small
  pressurised LPG ships in the Med/Black Sea; tankers VLCC → MR; LPG VLGC → pressurised.

## 3. Storyboard — five keyframes (`contract.ts` → `SCENES`)

Progress `p` (0..1) scrubs the journey; the page maps scroll to `p`. At each `at` the scene must be a
finished, beautiful composition; in between, the camera flies smoothly and the light changes
continuously (never cut through land; ease in/out of each keyframe).

| id | at | tone | Scene | Where copy sits (harness overlays it) |
| --- | --- | --- | --- | --- |
| hero | 0 | light | **The Bosphorus at first light.** Camera low over the strait looking north up the Bosphorus. Sky ≥ 55 % of the frame (desktop horizon ≈ 60–68 % from top). Left: European shore silhouettes (hills, a long low palace façade at the waterline, mosque domes with slender pencil minarets, a Galata-like round tower with a conical cap on a hill). Right: Asian shore hills + mosques; **Maiden's Tower** (Kız Kulesi) on its tiny islet mid-right in the water. The **Bosphorus Bridge** (two towers, catenary main cables, deck) spans the strait in the hazy distance. A **crude tanker** crossing in the mid-ground, right of centre. Sun just above the Asian hills (right), warm brass haze. | Headline block top-left on the sky (≈ left 55 % × top 20–60 %). Keep that area calm. |
| desks | 0.28 | light | **Open water.** Camera out in the Sea of Marmara, a little higher. A **tanker** (3/4 view, bow right) and a **gas carrier** (pressurised LPG: big horizontal cylindrical cargo tanks on deck — or a VLGC with deck domes) further off. Horizon higher (≈ 36–46 % from top) so the sea texture reads. Morning light. | Headline top-left; two white desk cards cover the bottom ≈ 40 %. Ships live between ≈ 25 % and 60 % height. |
| straits | 0.52 | light | **Under the bridge.** Golden hour near the Bosphorus Bridge, looking up the strait through/under its span; a gas carrier passing under it; an Ortaköy-like mosque (one dome, two minarets) at the European waterline (left). Low sun on the left (west) with a long glitter path. | Headline top-left; a paper band over the bottom ≈ 30 %. |
| process | 0.76 | dark | **Dusk on the Marmara.** Blue hour: navy sky, brass/rose afterglow at the horizon, the city skyline silhouette on the horizon with tiny window lights, ships at anchor with navigation lights, first stars. | A dark ink band across the middle ≈ 30–70 %. |
| contact | 1 | dark | **Night watch.** Deep navy night, moon with a glitter path, stars, Maiden's Tower lit (warm windows + beacon) foreground-right on its islet, distant city lights, a ship with deck lights. | Headline + buttons left-centre. |

Ambient life (frozen when `reducedMotion`): waves, ships drifting slowly with a foam wake, a few gulls
by day, star twinkle, beacon, light shimmer. Screenshots are taken at `setTime(12)` — it must look good there.

**Portrait / mobile (390×844):** the subject must stay in frame — widen vertical FOV for portrait so
horizontal coverage stays sensible, and/or shift the camera target per scene toward the subject.
Horizon on mobile hero ≈ 62–72 % from top (headline sits on the sky above it).

**Modeling notes.** Credible proportions matter more than detail: tanker L:B ≈ 6:1, low laden
freeboard, raked stem, flat sheer, accommodation block + funnel aft (brass funnel band = LEVANTER
livery), deck pipe rack; red/rust boot-top at the waterline. Gas carrier: same hull language with
2–4 horizontal cylindrical tanks (pressurised) or a trunk deck with domes. Bridge: real one is a
1,074 m span, 165 m towers — you may cheat scale/distances for composition. Minarets: very slender,
1–3 balconies, sharp conical cap. Use atmospheric perspective (farther = lighter/hazier, toward sky
colour). Land can be layered silhouette "flats" (ShapeGeometry at several depths) — a stage-set look
reads well and is cheap. Everything procedural (geometry, noise textures from canvas/DataTexture or
shader math). No image/video/font/network loads.

## 4. Engine contract (MUST match `$SP/proto/contract.ts`)

`$SP/proto/<TAKE>/src/index.ts` must `export const createVoyage: CreateVoyage` and
`export { SCENES as VOYAGE_SCENES } from "../../contract"`. Split the code into modules
(e.g. `engine.ts`, `timeline.ts` (keyframes, easing, palette per time of day), `sky.ts`, `ocean.ts`,
`ships.ts`, `skyline.ts`, `post.ts`, `noise.ts`) — the winner is ported file-by-file into the site.

- TypeScript strict (`npx tsc -p <TAKE>/tsconfig.json` must pass; no `any`, no `@ts-ignore`).
- three.js r187 only (`import * as THREE from "three"`; `three/examples/jsm/...` allowed if needed).
  No other runtime deps. A small custom post pass (render target + full-screen triangle) beats
  EffectComposer for weight.
- `getHorizonY()`: projected y (CSS px) of the far sea horizon for the current camera — the page draws
  a hairline there, so it must match the visible horizon exactly (the sea must reach the true horizon,
  e.g. a camera-following sea plane + fog, or a horizon-matched skirt).
- Quality tiers (`quality` option): high (desktop) → medium → low (phones). Cap DPR (e.g. high 1.75,
  medium 1.25, low 1). Budgets: high ≤ 45 draw calls, ≤ 300k triangles, ONE post pass; low ≤ 25 draw
  calls, ≤ 90k triangles, cheaper shaders. No shadow maps (fake the lighting). Reuse materials.
- `start()/stop()` own a rAF loop; `setProgress` may be smoothed in the loop but `renderOnce()` must
  render exactly the requested progress (screenshots rely on it). `setTime` overrides the clock.
- `reducedMotion`: no ambient animation at all; still frames per progress.
- WebGL context loss: stop and recover on `webglcontextrestored`. `dispose()` frees everything.
- Renderer: `antialias` only on high tier; `powerPreference: "high-performance"` is fine;
  output colour space sRGB; tone mapping your call.

## 5. Tooling

```bash
cd $SP/proto
# once: create <TAKE>/tsconfig.json → { "extends": "../tsconfig.base.json", "include": ["src", "../contract.ts"] }
npx tsc -p <TAKE>/tsconfig.json
npx esbuild <TAKE>/src/index.ts --bundle --format=esm --target=es2020 --minify --outfile=<TAKE>/dist/app.js --log-level=warning
node harness/shoot.cjs <TAKE> <PORT> --quick   # desktop hero/desks/contact only, fast
node harness/shoot.cjs <TAKE> <PORT>           # full set: 7 progress points × desktop+mobile, + clean desktop
```

Screenshots land in `$SP/proto/<TAKE>/shots/` (`desk-*.png`, `mob-*.png`, `desk-*-clean.png` without
overlays, `metrics.json` with frame cost in SwiftShader (CPU rasteriser — compare relatively), bundle
size, renderer.info, console errors). LOOK at them with the Read tool. The harness overlays the real
homepage copy, header, chart frame and the horizon hairline from `getHorizonY()`, so you can judge
legibility and composition. Live mode for poking: `harness/index.html?take=<TAKE>&live=1&p=0`
(wheel scrubs progress). Rendering in SwiftShader is slow: keep the full shoot under ~3 minutes.

## 6. Quality bar and process

This is a judge panel: three takes, one wins and gets ported. Judged on (a) beauty and art direction,
brand fit and how well it captures the reference's mood (cinematic painted sea journey, print
texture, horizon) while looking better; (b) composition and legibility of the copy at every keyframe on
desktop AND mobile, transitions included; (c) engineering: perf budget, clean portable TS, robustness.

Iterate. Do at least three critique → refine cycles on the screenshots before the final full shoot:
fix the weakest scene each time (composition, proportions of ships/landmarks, colour harmony, horizon
match, banding, aliasing, empty or busy areas behind text, mobile framing). Be your own harshest art
director: cheap-looking low-poly or flat CG reads as a failure here; aim for something a design-led
studio would ship.
