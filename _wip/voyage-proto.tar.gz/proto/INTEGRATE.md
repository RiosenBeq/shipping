# Porting the winning take into the LEVANTER site

Repo: `/home/user/shipping` (Next.js 14 App Router, TS strict, Tailwind, ESLint `next/core-web-vitals`,
Prettier with `prettier-plugin-tailwindcss`, Vitest). Branch `claude/nifty-wozniak-xu8qnc` — do NOT commit
or push; the lead does that.

## What already exists (do not rewrite unless something is broken)

- `components/site/voyage/types.ts` — the production contract. Identical to `$SP/proto/contract.ts`
  plus `VoyageOptions.onFrame?: (f: { horizonY: number | null; progress: number }) => void`, which the
  engine MUST call after every rendered frame (rAF loop and `renderOnce`). `VOYAGE_SCENES` lives here.
- `components/site/voyage/engine/index.ts` — a PLACEHOLDER engine. Replace the whole `engine/` folder
  with the winner's modules (`engine/index.ts` must export `createVoyage` and re-export `VOYAGE_SCENES`
  from `../types`). Change `../../contract` imports to `../types`.
- `components/site/voyage/VoyageStage.tsx` — client component: fixed full-viewport stage (z-index −1)
  behind the homepages; maps scroll → progress (`progress.ts`, unit-tested), picks a quality tier and a
  DPR budget (`quality.ts`, unit-tested), lazy-imports `./engine` on idle, runs/pauses the loop
  (IntersectionObserver on window sections + `visibilitychange`), reduced-motion stills, horizon hairline
  from `onFrame`, static painted CSS backdrop per scene as SSR/fallback (`app/voyage.css`). `?voyage=1`
  forces the live engine (needed in headless SwiftShader, which reports a "major performance caveat");
  `?voyage=0` forces the static backdrop.
- `components/site/voyage/VoyageRail.tsx` — section rail (xl+).
- `app/voyage.css` — stage, backdrop gradients per scene, chart frame, horizon, scrims, bands, rail, print.
- Homepages: `app/(site)/(home)/page.tsx` (English) and `app/[lang]/page.tsx` (10 localized). Window
  sections (transparent, `data-voyage-scene`): `#overview` (hero), `#desks`, `#why` (scene `straits`),
  `#process`, `#contact` (CtaBand `onStage`). Sheets (opaque): proof strip is INSIDE the hero as an ink
  band on the water; team / research / FAQ are opaque.

## Page layout the scenes must frame (desktop 1440×900 and phone 390×844)

- **hero**: header 64px (clear, navy text). Eyebrow + big serif H1 on the SKY, top-left, roughly
  y 14–46 % (desktop) / 12–38 % (phone). The lead paragraph, two buttons and a mono coordinates line sit
  on the WATER, bottom-left, y ≈ 62–95 % (desktop) / 54–95 % (phone), white/fog text on a soft radial ink
  scrim. → Horizon at **≈ 60 % desktop, ≈ 52 % phone**. Subjects (tanker, Maiden's Tower, skyline,
  bridge) along the horizon on the RIGHT half on desktop; on the phone the ship must read on the horizon
  line between the H1 and the lead. The water under the copy should be dark enough for white text.
- **desks**: heading top-left on the sky (y 12–35 %), two white cards from y ≈ 40 % down to the bottom.
  Horizon ≈ 40–44 %; ships upper-right, between the heading's right edge and the frame, above the cards.
- **straits** (`#why`): heading top-left on the sky (y 12–35 %); a paper band with four items covers the
  bottom ≈ 35 %. Horizon ≈ 56–60 %; bridge + gas carrier centre/right above the band.
- **process**: heading on the sky (y 15–35 %), an ink band with four steps across y ≈ 45–80 %. Horizon
  ≈ 58–62 %; afterglow and skyline lights visible above/around the band.
- **contact**: heading + text + buttons left-centre, a dark glass desk card on the right (y 30–75 %).
  Horizon ≈ 60–64 %; moon + glitter path + lit Maiden's Tower should read between/around them.

## Repo gates (all must pass)

```bash
cd /home/user/shipping
npx tsc --noEmit -p tsconfig.json
npx next lint
npx prettier --check .          # fix with: npx prettier --write <files>
npx vitest run
NEXT_TELEMETRY_DISABLED=1 npx next build   # stop any `next dev` first: both use .next/
```

## Screenshots of the real site

```bash
# dev server (stop it before `next build`):
cd /home/user/shipping && NEXT_TELEMETRY_DISABLED=1 npx next dev -p 3000 &
node $SP/scripts/shoot-site.cjs http://127.0.0.1:3000 <outDir>            # desktop + phone, every section
node $SP/scripts/shoot-site.cjs http://127.0.0.1:3000 <outDir> path=/de   # a localized page
node $SP/scripts/shoot-site.cjs http://127.0.0.1:3000 <outDir> --static   # fallback backdrop
```
