import * as THREE from "three";
import { rng } from "./math";

/**
 * The single post pass: prints the abstract plate onto paper.
 *  - palette: R (luminance) → dark ink .. light ground, G → brass, B → halation;
 *  - ink bleed: a 1-CSS-px soften, with paper fibre catching the line edges;
 *  - outlines: log-depth discontinuities (alpha) become engraved contour lines;
 *  - plate tone: a faint wiped-plate vignette; dither against banding.
 */
const VERT = /* glsl */ `
void main() { gl_Position = vec4(position.xy, 0.0, 1.0); }
`;

const FRAG = /* glsl */ `
uniform sampler2D tScene;
uniform sampler2D tPaper;
uniform vec2 uRes;
uniform float uDpr;
uniform vec3 uDark;
uniform vec3 uLight;
uniform vec3 uBrass;
uniform vec3 uGlowCol;
uniform vec3 uPlate;
uniform vec4 uPost;
uniform vec4 uEdge;
uniform float uLights;
float hash12(vec2 p) { vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
void main() {
  vec2 px = 1.0 / uRes;
  vec2 uv = gl_FragCoord.xy * px;
  float o = 0.7 * uDpr;
  vec4 c = texture2D(tScene, uv);
  vec4 l = texture2D(tScene, uv - vec2(o, 0.0) * px);
  vec4 r = texture2D(tScene, uv + vec2(o, 0.0) * px);
  vec4 d = texture2D(tScene, uv - vec2(0.0, o) * px);
  vec4 u = texture2D(tScene, uv + vec2(0.0, o) * px);
  float avg = 0.25 * (l.r + r.r + d.r + u.r);
  // ink bleed: soften, and let ink spread slightly into the paper
  float lum = mix(c.r, avg, uPost.x);
  lum = mix(lum, min(lum, avg), 0.25 * uPost.x);
  float paper = texture2D(tPaper, gl_FragCoord.xy / (256.0 * uDpr)).r;
  float edgeZone = clamp(lum * (1.0 - lum) * 4.0, 0.0, 1.0);
  lum = clamp(lum + (paper - 0.5) * uPost.y * edgeZone, 0.0, 1.0);

  // outlines where the depth code jumps (nearer side only)
  float e = max(max(l.a, r.a), max(d.a, u.a)) - c.a;
  float edge = smoothstep(0.012, 0.05, e) * uEdge.x * (1.0 - smoothstep(uEdge.z, uEdge.w, c.a));

  vec3 col = mix(uDark, uLight, lum);
  // paper tooth on the light ground
  col *= 1.0 + (paper - 0.5) * 0.07 * lum;
  float brass = mix(c.g, 0.25 * (l.g + r.g + d.g + u.g), 0.35 * uPost.x);
  col = mix(col, uBrass, clamp(brass, 0.0, 1.0));
  col = mix(col, mix(uDark, uLight, uEdge.y), edge);

  // halation around lights
  float s = 2.6 * uDpr;
  float h = texture2D(tScene, uv + vec2(s, s * 0.4) * px).b + texture2D(tScene, uv - vec2(s, s * 0.4) * px).b
          + texture2D(tScene, uv + vec2(-s * 0.4, s) * px).b + texture2D(tScene, uv + vec2(s * 0.4, -s) * px).b;
  float halo = c.b * 0.6 + h * 0.18 + 0.1 * (l.b + r.b + d.b + u.b);
  col += uGlowCol * halo * (0.35 + 0.65 * uLights);

  // plate tone vignette
  vec2 q = uv - 0.5;
  q.x *= uRes.x / uRes.y;
  float vig = smoothstep(0.4, 1.15, length(q) * 1.15);
  col = mix(col, col * uPlate, vig * uPost.z);
  col += (hash12(gl_FragCoord.xy) - 0.5) * (1.6 / 255.0);
  gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
`;

/** Tileable paper fibre texture (256², R8): soft clouding, fibres, grain. */
export function makePaperTexture(size = 256, seed = 11): THREE.DataTexture {
  const N = size * size;
  const f = new Float32Array(N);
  const r = rng(seed);
  for (const [period, amp] of [
    [8, 0.3],
    [16, 0.22],
    [32, 0.16],
    [64, 0.1],
  ] as const) {
    const grid = new Float32Array(period * period);
    for (let i = 0; i < grid.length; i++) grid[i] = r();
    const cell = size / period;
    for (let y = 0; y < size; y++) {
      const gy = y / cell;
      const y0 = Math.floor(gy);
      const fy = gy - y0;
      const uy = fy * fy * (3 - 2 * fy);
      for (let x = 0; x < size; x++) {
        const gx = x / cell;
        const x0 = Math.floor(gx);
        const fx = gx - x0;
        const ux = fx * fx * (3 - 2 * fx);
        const a = grid[(y0 % period) * period + (x0 % period)];
        const b = grid[(y0 % period) * period + ((x0 + 1) % period)];
        const c = grid[((y0 + 1) % period) * period + (x0 % period)];
        const d = grid[((y0 + 1) % period) * period + ((x0 + 1) % period)];
        f[y * size + x] += amp * (a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uy);
      }
    }
  }
  // fibres: short, gently curving strokes, some lighter some darker
  for (let k = 0; k < 1100; k++) {
    let x = r() * size;
    let y = r() * size;
    let ang = r() * Math.PI * 2;
    const len = 6 + r() * 30;
    const curv = (r() - 0.5) * 0.12;
    const amt = (r() < 0.55 ? 1 : -1) * (0.05 + r() * 0.09);
    for (let s = 0; s < len; s += 0.5) {
      x += Math.cos(ang) * 0.5;
      y += Math.sin(ang) * 0.5;
      ang += curv;
      const ix = ((Math.floor(x) % size) + size) % size;
      const iy = ((Math.floor(y) % size) + size) % size;
      f[iy * size + ix] += amt;
    }
  }
  let mean = 0;
  for (let i = 0; i < N; i++) {
    f[i] += (r() - 0.5) * 0.1;
    mean += f[i];
  }
  mean /= N;
  let v = 0;
  for (let i = 0; i < N; i++) v += (f[i] - mean) ** 2;
  const sd = Math.sqrt(v / N) || 1;
  const data = new Uint8Array(N);
  for (let i = 0; i < N; i++) data[i] = Math.max(0, Math.min(255, Math.round(128 + ((f[i] - mean) / sd) * 42)));
  const tex = new THREE.DataTexture(data, size, size, THREE.RedFormat, THREE.UnsignedByteType);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.magFilter = THREE.LinearFilter;
  tex.minFilter = THREE.LinearFilter;
  tex.generateMipmaps = false;
  tex.needsUpdate = true;
  return tex;
}

export interface Post {
  mesh: THREE.Mesh;
  material: THREE.ShaderMaterial;
  paper: THREE.DataTexture;
  u: ReturnType<typeof postUniforms>;
}

function postUniforms(paper: THREE.Texture) {
  return {
    tScene: { value: null as THREE.Texture | null },
    tPaper: { value: paper },
    uRes: { value: new THREE.Vector2(1, 1) },
    uDpr: { value: 1 },
    uDark: { value: new THREE.Vector3() },
    uLight: { value: new THREE.Vector3(1, 1, 1) },
    uBrass: { value: new THREE.Vector3() },
    uGlowCol: { value: new THREE.Vector3() },
    uPlate: { value: new THREE.Vector3(0.93, 0.91, 0.87) },
    /** x bleed, y fibre, z vignette, w unused. */
    uPost: { value: new THREE.Vector4(0.35, 0.25, 0.35, 0) },
    /** x strength, y edge luminance (0 ink / 1 light), z,w depth-code fade range. */
    uEdge: { value: new THREE.Vector4(0.8, 0, 0.7, 0.93) },
    uLights: { value: 0 },
  };
}

export function createPost(): Post {
  const paper = makePaperTexture();
  const u = postUniforms(paper);
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute([-1, -1, 0, 3, -1, 0, -1, 3, 0], 3));
  const material = new THREE.ShaderMaterial({
    uniforms: u,
    vertexShader: VERT,
    fragmentShader: FRAG,
    depthTest: false,
    depthWrite: false,
  });
  const mesh = new THREE.Mesh(g, material);
  mesh.frustumCulled = false;
  return { mesh, material, paper, u };
}
