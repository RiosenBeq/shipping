import { MeshBuilder, STYLE } from "./geometry";
import { fbm1, hash1, lerp, rng, smoothstep, type V2 } from "./math";

/**
 * Coast "curtains": vertical silhouette flats that follow a coastline, the
 * stage-set way. Several per shore (waterfront, hills, far ridge) give the
 * layered depth of an engraved coastal view; aerial perspective in the shader
 * pales the far ones. Urban stretches get crisp building-block steps (and
 * window lights at night); green ones get rolling tree-line profiles.
 */
export interface CurtainSpec {
  pts: V2[];
  /** Height control points along the normalised length: [t, metres]. */
  base: [number, number][];
  hillAmp: number;
  hillScale: number;
  /** 0..1: share of building blocks on the skyline. */
  urban: number;
  blockH: [number, number];
  blockW: [number, number];
  step: number;
  tone: number;
  seed: number;
  closed?: boolean;
  /** Extra local bumps: [t, height, half-width in metres]. */
  peaks?: [number, number, number][];
}

interface Walker {
  len: number;
  at(s: number): { x: number; z: number; nx: number; nz: number };
}

function walker(ptsIn: V2[], closed: boolean): Walker {
  const pts = closed ? [...ptsIn, ptsIn[0]] : ptsIn;
  const cum: number[] = [0];
  for (let i = 1; i < pts.length; i++) {
    cum.push(cum[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
  }
  const len = cum[cum.length - 1];
  return {
    len,
    at(s: number) {
      const ss = Math.max(0, Math.min(len, s));
      let i = 1;
      while (i < cum.length - 1 && cum[i] < ss) i++;
      const t = (ss - cum[i - 1]) / Math.max(cum[i] - cum[i - 1], 1e-6);
      const [x0, z0] = pts[i - 1];
      const [x1, z1] = pts[i];
      const dx = x1 - x0;
      const dz = z1 - z0;
      const l = Math.hypot(dx, dz) || 1;
      return { x: lerp(x0, x1, t), z: lerp(z0, z1, t), nx: -dz / l, nz: dx / l };
    },
  };
}

function baseHeight(base: [number, number][], t: number): number {
  if (t <= base[0][0]) return base[0][1];
  for (let i = 1; i < base.length; i++) {
    if (t <= base[i][0]) {
      const u = (t - base[i - 1][0]) / (base[i][0] - base[i - 1][0]);
      return lerp(base[i - 1][1], base[i][1], u * u * (3 - 2 * u));
    }
  }
  return base[base.length - 1][1];
}

/** Skyline breakpoints (s, h): building steps are emitted as vertical pairs. */
function profile(c: CurtainSpec, len: number): [number, number][] {
  const r = rng(c.seed);
  const hill = (s: number): number => {
    const t = s / len;
    let h = baseHeight(c.base, t) + c.hillAmp * (fbm1(s / c.hillScale, c.seed) - 0.5) * 2;
    for (const [pt, ph, pw] of c.peaks ?? []) {
      const d = (s - pt * len) / pw;
      h += ph * Math.exp(-d * d);
    }
    return Math.max(h, 1);
  };
  const out: [number, number][] = [];
  let s = 0;
  if (c.urban > 0) {
    while (s < len) {
      const w = lerp(c.blockW[0], c.blockW[1], r());
      const e = Math.min(len, s + w);
      const built = r() < c.urban;
      const hm = hill((s + e) / 2);
      if (built) {
        const bh = lerp(c.blockH[0], c.blockH[1], r() ** 1.6);
        out.push([s, hm + bh], [e, hm + bh]);
      } else {
        // trees / gaps between blocks: soft bumps
        const n = Math.max(2, Math.round((e - s) / 6));
        for (let k = 0; k <= n; k++) {
          const ss = lerp(s, e, k / n);
          out.push([ss, hill(ss) + 3 + 4 * hash1(Math.floor(ss / 5), c.seed)]);
        }
      }
      s = e;
    }
  } else {
    const treeAmt = 1 - smoothstep(30, 80, c.step);
    for (; s <= len; s += c.step) {
      const tree = (fbm1(s / 18, c.seed + 5) - 0.5) * 6 + (fbm1(s / 5, c.seed + 9) - 0.5) * 2.5;
      out.push([s, hill(s) + tree * treeAmt]);
    }
    if (out.length && out[out.length - 1][0] < len) out.push([len, hill(len)]);
  }
  return out;
}

export function buildCurtain(b: MeshBuilder, c: CurtainSpec): void {
  const w = walker(c.pts, !!c.closed);
  const prof = profile(c, w.len);
  b.urban = c.urban;
  b.seed = (c.seed % 97) / 97;
  b.place = { x: 0, y: 0, z: 0 };
  const m = { tone: c.tone, style: STYLE.CURTAIN };
  let prevTop = -1;
  let prevBot = -1;
  for (const [s, h] of prof) {
    const p = w.at(s);
    const n: [number, number, number] = [p.nx, 0, p.nz];
    const bot = b.vertex([p.x, -60, p.z], n, m, s);
    const top = b.vertex([p.x, h, p.z], n, m, s);
    if (prevTop >= 0) b.quad(prevBot, bot, top, prevTop);
    prevTop = top;
    prevBot = bot;
  }
  b.urban = 0;
  b.seed = 0;
}

/** Closed island outline with a noisy radius. */
export function islandPts(cx: number, cz: number, r: number, seed: number, n = 28): V2[] {
  const out: V2[] = [];
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    const rr = r * (0.75 + 0.5 * fbm1(i * 0.35, seed));
    out.push([cx + Math.cos(a) * rr * 1.5, cz + Math.sin(a) * rr]);
  }
  return out;
}
