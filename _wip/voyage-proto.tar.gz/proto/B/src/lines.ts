import * as THREE from "three";
import { GLSL_COMMON } from "./glsl";
import type { V3 } from "./math";
import type { Shared } from "./uniforms";

/**
 * Hairlines: world-space polylines expanded to screen-space ribbons and
 * anti-aliased analytically (exact box coverage across, box-filtered dashes
 * along). Used for everything finer than a pixel or two: minarets, masts,
 * bridge cables and hangers, rim/sheer lines, window rows, lights.
 */
export const LINE = {
  /** navy ink by day, fades with haze. */
  DARK: 0,
  /** engraved highlight: paper by day, sand by night. */
  LIGHT: 1,
  /** brass accent. */
  BRASS: 2,
  /** light source: only at night (deck lights, beacon). */
  GLOW: 3,
  /** window rows: paper dashes by day, lit brass by night. */
  WINDOW: 4,
  /** flashing beacon (night only). */
  BEACON: 5,
} as const;

export interface LineStyle {
  kind: number;
  /** Minimum width in CSS px (at the A end). */
  px: number;
  /** Width in CSS px at the B end (taper); defaults to px. */
  pxB?: number;
  /** Physical width in metres (wins when it projects wider than px). */
  world?: number;
  /** Physical width at the B end (taper); defaults to world. */
  worldB?: number;
  alpha?: number;
  /** Dash period in metres (0 = solid) and duty cycle. */
  dash?: number;
  duty?: number;
}

const CORNERS: [number, number][] = [
  [0, -1],
  [0, 1],
  [1, 1],
  [1, -1],
];

export class LineBuilder {
  private a: number[] = [];
  private b: number[] = [];
  private corner: number[] = [];
  private style: number[] = [];
  private dash: number[] = [];
  private idx: number[] = [];
  ship = -1;

  seg(A: V3, B: V3, st: LineStyle, lenA = 0): number {
    const L = Math.hypot(B[0] - A[0], B[1] - A[1], B[2] - A[2]);
    const base = this.a.length / 3;
    for (const [along, side] of CORNERS) {
      this.a.push(A[0], A[1], A[2]);
      this.b.push(B[0], B[1], B[2]);
      this.corner.push(along, side);
      const atB = along > 0.5;
      this.style.push(atB ? st.pxB ?? st.px : st.px, st.kind, atB ? st.worldB ?? st.world ?? 0 : st.world ?? 0, st.alpha ?? 1);
      this.dash.push(lenA + along * L, st.dash ?? 0, st.duty ?? 0.5, this.ship);
    }
    this.idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
    return L;
  }

  poly(pts: V3[], st: LineStyle, closed = false): void {
    let acc = 0;
    const n = pts.length;
    const m = closed ? n : n - 1;
    for (let i = 0; i < m; i++) acc += this.seg(pts[i], pts[(i + 1) % n], st, acc);
  }

  /** A light point (deck light, beacon): a zero-length round dot. */
  dot(p: V3, px: number, kind: number = LINE.GLOW, alpha = 1): void {
    this.seg(p, [p[0], p[1] + 0.01, p[2]], { kind, px, alpha });
  }

  build(): THREE.BufferGeometry {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(this.a, 3));
    g.setAttribute("aB", new THREE.Float32BufferAttribute(this.b, 3));
    g.setAttribute("aCorner", new THREE.Float32BufferAttribute(this.corner, 2));
    g.setAttribute("aStyle", new THREE.Float32BufferAttribute(this.style, 4));
    g.setAttribute("aDash", new THREE.Float32BufferAttribute(this.dash, 4));
    const n = this.a.length / 3;
    g.setIndex(n > 65535 ? new THREE.Uint32BufferAttribute(this.idx, 1) : new THREE.Uint16BufferAttribute(this.idx, 1));
    return g;
  }
}

/** Ship pose transform shared by solids and lines (GLSL). */
export const GLSL_SHIP = /* glsl */ `
uniform vec4 uShipPose[8];
uniform vec4 uShipMot[8];
vec3 shipPoint(vec3 p, int i) {
  vec4 ps = uShipPose[i];
  vec4 mo = uShipMot[i];
  p *= mo.z;
  p.y += p.x * mo.x + p.z * mo.y;
  float c = cos(ps.z);
  float s = sin(ps.z);
  return vec3(ps.x + p.x * s + p.z * c, p.y + ps.w, ps.y - p.x * c + p.z * s);
}
vec3 shipNormal(vec3 n, int i) {
  float h = uShipPose[i].z;
  float c = cos(h);
  float s = sin(h);
  return vec3(n.x * s + n.z * c, n.y, -n.x * c + n.z * s);
}
`;

const VERT = /* glsl */ `
attribute vec3 aB;
attribute vec2 aCorner;
attribute vec4 aStyle;
attribute vec4 aDash;
uniform vec2 uRes;
uniform float uDpr;
uniform vec3 uCamPos;
uniform vec2 uNearFar;
${GLSL_SHIP}
varying float vAcross;
varying float vHalfW;
varying float vAlong;
varying float vDist;
varying vec4 vStyle;
varying vec4 vDash;
void main() {
  vec3 A = position;
  vec3 B = aB;
  if (aDash.w > -0.5) {
    int si = int(aDash.w + 0.5);
    A = shipPoint(A, si);
    B = shipPoint(B, si);
  }
  // depth bias: slide endpoints 0.25 % toward the camera (screen position unchanged)
  A = uCamPos + (A - uCamPos) * 0.9975;
  B = uCamPos + (B - uCamPos) * 0.9975;
  mat4 pv = projectionMatrix * viewMatrix;
  vec4 ca = pv * vec4(A, 1.0);
  vec4 cb = pv * vec4(B, 1.0);
  bool atB = aCorner.x > 0.5;
  vec4 c = atB ? cb : ca;
  if (ca.w < uNearFar.x || cb.w < uNearFar.x) {
    gl_Position = vec4(0.0, 0.0, 2.0, 1.0);
    return;
  }
  vec2 sa = ca.xy / ca.w * 0.5 * uRes;
  vec2 sb = cb.xy / cb.w * 0.5 * uRes;
  vec2 d = sb - sa;
  float len = length(d);
  vec2 t = len > 1e-3 ? d / len : vec2(0.0, 1.0);
  vec2 n = vec2(-t.y, t.x);
  float pxPerM = projectionMatrix[1][1] * 0.5 * uRes.y / c.w;
  float wpx = max(aStyle.x * uDpr, aStyle.z * pxPerM);
  float hw = 0.5 * wpx + 1.0;
  vec2 off = n * aCorner.y * hw + t * (atB ? 1.0 : -1.0) * min(hw, 0.5 * wpx + 1.0);
  c.xy += off / (0.5 * uRes) * c.w;
  gl_Position = c;
  vAcross = aCorner.y * hw;
  vHalfW = 0.5 * wpx;
  vAlong = aDash.x;
  vDist = length((atB ? B : A) - uCamPos);
  vStyle = aStyle;
  vDash = aDash;
}
`;

const FRAG = /* glsl */ `
uniform vec4 uFog;
uniform float uLights;
uniform float uNight;
uniform float uTime;
varying float vAcross;
varying float vHalfW;
varying float vAlong;
varying float vDist;
varying vec4 vStyle;
varying vec4 vDash;
${GLSL_COMMON}
void main() {
  float cov = lineBox(abs(vAcross), vHalfW);
  if (vDash.y > 0.0) {
    float u = vAlong / vDash.y;
    cov *= dashCov(u, vDash.z, fwidth(u));
  }
  float kind = vStyle.y;
  float F = (1.0 - exp(-vDist / uFog.x)) * uFog.z;
  float lum = 1.0;
  float brass = 0.0;
  float glow = 0.0;
  float a = vStyle.w;
  if (kind < 0.5) {
    // ink, paling with the haze
    lum = mix(0.0, uFog.y, F) + 0.1 * uNight;
    a *= 1.0 - 0.3 * F;
  } else if (kind < 1.5) {
    // engraved highlight
    a *= (1.0 - 0.8 * F) * (1.0 - 0.5 * uNight);
  } else if (kind < 2.5) {
    brass = 1.0;
    a *= 1.0 - 0.7 * F;
  } else if (kind < 3.5) {
    brass = 0.5;
    glow = 1.0;
    a *= uLights;
  } else if (kind < 4.5) {
    // windows: paper dashes by day, lit brass at night
    brass = 0.8 * uLights;
    glow = 0.7 * uLights;
    a *= max((1.0 - F) * 0.8 * (1.0 - uNight), uLights);
  } else {
    float ph = fract(uTime / 3.4 + 0.55);
    float blink = smoothstep(0.0, 0.05, ph) * (1.0 - smoothstep(0.22, 0.4, ph));
    brass = 0.6;
    glow = 1.0;
    a *= uLights * (0.25 + 0.75 * blink);
  }
  cov *= a;
  if (cov < 0.004) discard;
  gl_FragColor = vec4(lum, brass, glow, cov);
}
`;

export function createLineMaterial(shared: Shared): THREE.ShaderMaterial {
  return new THREE.ShaderMaterial({
    uniforms: { ...shared },
    vertexShader: VERT,
    fragmentShader: FRAG,
    transparent: true,
    depthWrite: false,
    depthTest: true,
    blending: THREE.CustomBlending,
    blendEquation: THREE.AddEquation,
    blendSrc: THREE.SrcAlphaFactor,
    blendDst: THREE.OneMinusSrcAlphaFactor,
    blendEquationAlpha: THREE.AddEquation,
    blendSrcAlpha: THREE.ZeroFactor,
    blendDstAlpha: THREE.OneFactor,
  });
}
