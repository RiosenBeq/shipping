import * as THREE from "three";
import { MeshBuilder } from "./geometry";
import { buildCurtain, islandPts, type CurtainSpec } from "./land";
import { bridge, galata, maidensTower, mosque, palace, topkapi, type MosqueSpec } from "./landmarks";
import { LineBuilder } from "./lines";
import { buildShips, type ShipDef } from "./ships";

/**
 * The map (metres; x east, z south, north = −z). The Bosphorus runs NNW from
 * its mouth near z ≈ 900; the historic peninsula lies south-west of the mouth,
 * the Sea of Marmara opens to the south. Distances are cheated a little for
 * composition, never for continuity: every keyframe sees the same city.
 */
export const TOWER = { x: 430, z: 780 } as const;
export const GALATA = { x: -1350, z: -1450, y: 84 } as const;

const COASTS: CurtainSpec[] = [
  // European waterfront: Golden Horn north bank → Karaköy → Beşiktaş → Ortaköy → Bebek
  {
    pts: [
      [-3500, -200],
      [-2600, 100],
      [-1800, 250],
      [-1150, 350],
      [-1080, 0],
      [-1020, -400],
      [-985, -900],
      [-975, -1400],
      [-970, -1900],
      [-960, -2400],
      [-930, -2900],
      [-860, -3300],
      [-810, -3450],
      [-790, -3800],
      [-830, -4400],
      [-900, -5200],
      [-880, -6200],
      [-950, -7600],
      [-1000, -9500],
    ],
    base: [
      [0, 8],
      [0.3, 6],
      [0.5, 4],
      [1, 6],
    ],
    hillAmp: 3,
    hillScale: 300,
    urban: 0.8,
    blockH: [6, 22],
    blockW: [9, 30],
    step: 10,
    tone: 0.46,
    seed: 11,
  },
  // European hills: Pera / Cihangir / Nişantaşı ridge
  {
    pts: [
      [-1600, 500],
      [-1420, -500],
      [-1300, -1400],
      [-1330, -2400],
      [-1280, -3500],
      [-1240, -4500],
      [-1330, -5700],
      [-1400, -7200],
      [-1500, -9500],
    ],
    base: [
      [0, 55],
      [0.15, 82],
      [0.35, 95],
      [0.6, 80],
      [1, 110],
    ],
    hillAmp: 16,
    hillScale: 420,
    urban: 0.7,
    blockH: [6, 16],
    blockW: [10, 28],
    step: 12,
    tone: 0.5,
    seed: 23,
  },
  // European far ridge
  {
    pts: [
      [-2900, 600],
      [-2500, -2500],
      [-2300, -5500],
      [-2600, -9500],
    ],
    base: [
      [0, 120],
      [0.5, 165],
      [1, 150],
    ],
    hillAmp: 22,
    hillScale: 700,
    urban: 0,
    blockH: [0, 0],
    blockW: [10, 10],
    step: 40,
    tone: 0.58,
    seed: 31,
  },
  // Asian waterfront: Moda → Kadıköy → Haydarpaşa → Salacak → Üsküdar → Beylerbeyi → Çengelköy
  {
    pts: [
      [1700, 3200],
      [1350, 2300],
      [1150, 1500],
      [950, 900],
      [880, 400],
      [860, -100],
      [820, -700],
      [760, -1500],
      [700, -2300],
      [560, -3000],
      [267, -3420],
      [330, -4200],
      [420, -5200],
      [460, -6400],
      [520, -7800],
      [600, -9500],
    ],
    base: [
      [0, 6],
      [0.4, 5],
      [1, 6],
    ],
    hillAmp: 3,
    hillScale: 300,
    urban: 0.72,
    blockH: [5, 18],
    blockW: [9, 26],
    step: 10,
    tone: 0.46,
    seed: 41,
  },
  // Asian hills with Çamlıca
  {
    pts: [
      [2400, 3000],
      [1900, 1500],
      [1500, 400],
      [1380, -600],
      [1300, -1500],
      [1250, -2200],
      [1000, -3300],
      [900, -4400],
      [1000, -6000],
      [1150, -9500],
    ],
    base: [
      [0, 60],
      [0.25, 105],
      [0.4, 140],
      [0.6, 150],
      [1, 160],
    ],
    hillAmp: 18,
    hillScale: 500,
    urban: 0.35,
    blockH: [5, 12],
    blockW: [12, 30],
    step: 14,
    tone: 0.52,
    seed: 53,
    peaks: [[0.41, 95, 380]],
  },
  // Asian Marmara shore: Moda → Fenerbahçe → Kartal
  {
    pts: [
      [1700, 3200],
      [2300, 4100],
      [3300, 4700],
      [4600, 5300],
      [7000, 6400],
      [10500, 8200],
      [15000, 10500],
    ],
    base: [
      [0, 8],
      [1, 10],
    ],
    hillAmp: 4,
    hillScale: 300,
    urban: 0.6,
    blockH: [6, 22],
    blockW: [12, 40],
    step: 12,
    tone: 0.5,
    seed: 61,
  },
  {
    pts: [
      [2700, 2500],
      [4200, 3700],
      [7200, 5100],
      [11000, 7000],
      [16000, 9400],
    ],
    base: [
      [0, 50],
      [0.5, 120],
      [1, 180],
    ],
    hillAmp: 26,
    hillScale: 800,
    urban: 0,
    blockH: [0, 0],
    blockW: [10, 10],
    step: 40,
    tone: 0.56,
    seed: 67,
  },
  // Historic peninsula: Golden Horn south bank → Seraglio Point → Marmara walls
  {
    pts: [
      [-3200, 200],
      [-2300, 450],
      [-1600, 600],
      [-1150, 760],
      [-920, 1050],
      [-1050, 1600],
      [-1500, 2150],
      [-2200, 2450],
      [-3000, 2600],
      [-4000, 2750],
      [-5200, 2950],
      [-6800, 3300],
      [-9000, 3800],
    ],
    base: [
      [0, 8],
      [0.35, 12],
      [1, 10],
    ],
    hillAmp: 3,
    hillScale: 300,
    urban: 0.75,
    blockH: [6, 18],
    blockW: [9, 28],
    step: 10,
    tone: 0.47,
    seed: 71,
  },
  // the peninsula's hills
  {
    pts: [
      [-1300, 1150],
      [-1600, 1520],
      [-2100, 1330],
      [-2500, 950],
      [-3000, 1200],
      [-3600, 1500],
      [-4400, 1800],
      [-5500, 2200],
      [-7000, 2700],
    ],
    base: [
      [0, 30],
      [0.25, 42],
      [0.45, 56],
      [1, 50],
    ],
    hillAmp: 8,
    hillScale: 300,
    urban: 0.8,
    blockH: [6, 15],
    blockW: [9, 24],
    step: 10,
    tone: 0.5,
    seed: 79,
  },
  // Princes' Islands
  {
    pts: islandPts(6500, 14500, 800, 3),
    base: [
      [0, 90],
      [0.5, 150],
      [1, 90],
    ],
    hillAmp: 30,
    hillScale: 600,
    urban: 0,
    blockH: [0, 0],
    blockW: [10, 10],
    step: 60,
    tone: 0.55,
    seed: 83,
    closed: true,
  },
  {
    pts: islandPts(9000, 16000, 1300, 5),
    base: [
      [0, 120],
      [0.5, 210],
      [1, 120],
    ],
    hillAmp: 40,
    hillScale: 700,
    urban: 0,
    blockH: [0, 0],
    blockW: [10, 10],
    step: 70,
    tone: 0.55,
    seed: 89,
    closed: true,
  },
  // far southern shore, a low line on the Marmara horizon
  {
    pts: [
      [-42000, 27000],
      [-15000, 25500],
      [0, 26500],
      [20000, 25000],
      [42000, 26000],
    ],
    base: [
      [0, 260],
      [0.5, 380],
      [1, 300],
    ],
    hillAmp: 120,
    hillScale: 3000,
    urban: 0,
    blockH: [0, 0],
    blockW: [10, 10],
    step: 400,
    tone: 0.6,
    seed: 97,
  },
];

const MOSQUES: MosqueSpec[] = [
  // Bosphorus, European side
  { x: -1030, z: -420, y0: 2, R: 8, minarets: 2, yaw: 1.4, tone: 0.66 },
  { x: -960, z: -1600, y0: 2, R: 7, minarets: 2, yaw: 1.5, tone: 0.7, minH: 5.2 },
  { x: -812, z: -3320, y0: 1, R: 9, minarets: 2, yaw: 1.3, tone: 0.72, minH: 4.6 },
  // Asian side: Üsküdar waterfront, Çamlıca hilltop
  { x: 885, z: 300, y0: 2, R: 9, minarets: 2, yaw: -1.4, tone: 0.66 },
  { x: 930, z: -10, y0: 3, R: 9.5, minarets: 2, yaw: -1.5, tone: 0.64, semi: true },
  { x: 1270, z: -2260, y0: 236, R: 17, minarets: 6, yaw: -1.2, tone: 0.7, minH: 4.2, semi: true },
  // the historic skyline
  { x: -1470, z: 1420, y0: 36, R: 16, minarets: 4, yaw: 0.25, tone: 0.6, semi: true, minH: 3.8 },
  { x: -1760, z: 1720, y0: 32, R: 12, minarets: 6, yaw: 0.2, tone: 0.66, semi: true, minH: 5.2 },
  { x: -2420, z: 680, y0: 58, R: 13, minarets: 4, yaw: 0.1, tone: 0.64, semi: true, minH: 5.4 },
  { x: -1360, z: 700, y0: 4, R: 9, minarets: 2, yaw: 0.3, tone: 0.64, semi: true },
  { x: -2780, z: 1240, y0: 50, R: 9, minarets: 2, yaw: 0.0, tone: 0.62 },
  { x: -3520, z: 930, y0: 60, R: 12, minarets: 2, yaw: 0.0, tone: 0.62, semi: true },
];

/** Every ship in the voyage (index = slot in the pose uniforms). */
export const SHIPS: ShipDef[] = [
  { type: "tanker", x: 300, z: 1000, heading: 275, L: 240, speed: 0.75, drift: 14 },
  { type: "tanker", x: 1593, z: 6047, heading: 340, L: 240, speed: 1, drift: 18 },
  { type: "gas", x: 1360, z: 7105, heading: 300, L: 150, speed: 0.8, drift: 14 },
  { type: "gas", x: -250, z: -3380, heading: 335, L: 160, speed: 0.7, drift: 14 },
  { type: "tanker", x: -2100, z: 3700, heading: 70, L: 200, speed: 0, drift: 0 },
  { type: "gas", x: -1050, z: 3500, heading: 110, L: 150, speed: 0, drift: 0 },
  { type: "tanker", x: -511, z: 2437, heading: 120, L: 220, speed: 0.25, drift: 6 },
  { type: "tanker", x: -2900, z: 3300, heading: 40, L: 130, speed: 0, drift: 0 },
];

export interface WorldGeometry {
  solid: THREE.BufferGeometry;
  lines: THREE.BufferGeometry;
}

export function buildWorld(detail: number): WorldGeometry {
  const b = new MeshBuilder();
  const L = new LineBuilder();
  for (const c of COASTS) {
    const spec = detail < 1 ? { ...c, step: c.step * 1.6, blockW: [c.blockW[0] * 1.4, c.blockW[1] * 1.4] as [number, number] } : c;
    buildCurtain(b, spec);
  }
  for (const m of MOSQUES) mosque(b, L, m);
  galata(b, L, GALATA.x, GALATA.z, GALATA.y);
  maidensTower(b, L, TOWER.x, TOWER.z);
  bridge(b, L);
  palace(b, L);
  topkapi(b, L);
  buildShips(b, L, SHIPS);
  return { solid: b.build(), lines: L.build() };
}
