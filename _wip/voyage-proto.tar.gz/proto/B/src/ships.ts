import { MeshBuilder, STYLE } from "./geometry";
import { LINE, LineBuilder } from "./lines";
import { smoothstep, type V3 } from "./math";

/**
 * Ships in LEVANTER livery, after the site's line-art vessels: low laden
 * freeboard, raked stem, flat sheer, accommodation and funnel aft (brass
 * band), deck pipe rack. Geometry is ship-local (x forward, y up, z
 * starboard) and posed in the vertex shader, so all ships share one draw.
 */
export interface ShipDef {
  type: "tanker" | "gas";
  x: number;
  z: number;
  /** Degrees clockwise from north. */
  heading: number;
  L: number;
  /** Wake strength 0..1 (0 = at anchor). */
  speed: number;
  /** Bounded drift amplitude along the heading (m). */
  drift: number;
}

interface Hull {
  L: number;
  B: number;
  F: number;
  rake: number;
  bowFrac: number;
  fc: number;
}

function halfBreadth(q: number, d: Hull): number {
  const B2 = d.B / 2;
  if (q < 0.07) return B2 * (0.84 + 0.16 * smoothstep(0, 0.07, q));
  if (q > 1 - d.bowFrac) {
    const r = (q - (1 - d.bowFrac)) / d.bowFrac;
    return B2 * Math.pow(Math.max(0, 1 - Math.pow(r, 2.3)), 0.6);
  }
  return B2;
}

interface Ring {
  x: number;
  y: number;
  hb: number;
}

function hull(b: MeshBuilder, L: LineBuilder, d: Hull, toneHull: number, toneDeck: number): Ring[] {
  const N = 34;
  const ts: number[] = [];
  for (let i = 0; i <= N; i++) ts.push(0.5 - 0.5 * Math.cos((Math.PI * i) / N));
  const xs = -d.L / 2;
  const deckY = (x: number): number => d.F + d.fc * smoothstep(d.L / 2 - 0.17 * d.L, d.L / 2 - 0.12 * d.L, x);
  const ring = (top: boolean): Ring[] =>
    ts.map((t) => {
      const xb = top ? d.L / 2 : d.L / 2 - d.rake;
      const x = xs + t * (xb - xs);
      return { x, y: top ? deckY(x) : 0, hb: halfBreadth(t, d) * (top ? 1 : 0.97) };
    });
  const bot = ring(false);
  const top = ring(true);
  const hullM = { tone: toneHull, style: STYLE.HULL };
  for (const side of [-1, 1]) {
    const ib: number[] = [];
    const it: number[] = [];
    for (let i = 0; i <= N; i++) {
      const i0 = Math.max(0, i - 1);
      const i1 = Math.min(N, i + 1);
      const dx = top[i1].x - top[i0].x;
      const dh = top[i1].hb - top[i0].hb;
      const l = Math.hypot(dh, dx) || 1;
      const n: V3 = [-dh / l, 0.08, (side * dx) / l];
      ib.push(b.vertex([bot[i].x, 0, side * bot[i].hb], n, hullM));
      it.push(b.vertex([top[i].x, top[i].y, side * top[i].hb], n, hullM));
    }
    for (let i = 0; i < N; i++) b.quad(ib[i], ib[i + 1], it[i + 1], it[i]);
  }
  const deckM = { tone: toneDeck, style: STYLE.DECK };
  const dp: number[] = [];
  const ds: number[] = [];
  for (let i = 0; i <= N; i++) {
    dp.push(b.vertex([top[i].x, top[i].y, -top[i].hb], [0, 1, 0], deckM));
    ds.push(b.vertex([top[i].x, top[i].y, top[i].hb], [0, 1, 0], deckM));
  }
  for (let i = 0; i < N; i++) b.quad(dp[i], dp[i + 1], ds[i + 1], ds[i]);
  b.face([xs, 0, bot[0].hb], [xs, 0, -bot[0].hb], [xs, top[0].y, -top[0].hb], [xs, top[0].y, top[0].hb], hullM);
  // engraved highlights: sheer line and boot-top
  for (const side of [-1, 1]) {
    L.poly(
      top.map((p) => [p.x, p.y + 0.05, side * p.hb] as V3),
      { kind: LINE.LIGHT, px: 0.9, world: 0.3 },
    );
    const by = 1.75;
    L.poly(
      top.map((p, i) => {
        const k = by / p.y;
        const q = bot[i];
        return [q.x + (p.x - q.x) * k, by, side * (q.hb + (p.hb - q.hb) * k + 0.05)] as V3;
      }),
      { kind: LINE.LIGHT, px: 0.7, alpha: 0.75, world: 0.2 },
    );
  }
  return top;
}

/** Window rows on the four faces of an accommodation block. */
function windows(L: LineBuilder, cx: number, y0: number, sx: number, sz: number, rows: number[], dash: number): void {
  const st = { kind: LINE.WINDOW, px: 1.05, world: 0.9, dash, duty: 0.52 };
  const hx = sx / 2 + 0.06;
  const hz = sz / 2 + 0.06;
  for (const r of rows) {
    const y = y0 + r;
    L.seg([cx + hx, y, -hz + 1], [cx + hx, y, hz - 1], st);
    L.seg([cx - hx, y, -hz + 1], [cx - hx, y, hz - 1], st);
    L.seg([cx - hx + 1, y, hz], [cx + hx - 1, y, hz], st);
    L.seg([cx - hx + 1, y, -hz], [cx + hx - 1, y, -hz], st);
  }
}

function superstructure(b: MeshBuilder, L: LineBuilder, d: Hull, scale: number): void {
  const F = d.F;
  const ax = -d.L / 2;
  const k = scale;
  const sup = { tone: 0.44 };
  const dark = { tone: 0.24 };
  const accX = ax + 20 * k;
  const accW = 22 * k;
  const accH = 13.5 * k;
  b.box(accX, F, 0, accW, accH, 0.74 * d.B, sup);
  b.box(accX + 1.5 * k, F + accH, 0, 14 * k, 3.2 * k, d.B * 0.98, sup);
  b.box(accX + 2 * k, F + accH + 3.2 * k, 0, 9 * k, 2.3 * k, 0.38 * d.B, sup);
  // raked funnel with the brass livery band
  const fx = ax + 7 * k;
  b.box(fx, F + 7 * k, 0, 8.5 * k, 13 * k, 7.5 * k, dark, 0.84);
  b.box(fx, F + 15.6 * k, 0, 7.75 * k, 2.6 * k, 6.85 * k, { tone: 0.82, brass: 1 });
  windows(L, accX, F, accW, 0.74 * d.B, [3.2 * k, 6.6 * k, 10 * k], 2.3 * k);
  const bw = { kind: LINE.WINDOW, px: 1.2, world: 1.0, dash: 1.7 * k, duty: 0.78 };
  const bx = accX + 8.55 * k;
  L.seg([bx, F + accH + 1.7 * k, -0.47 * d.B], [bx, F + accH + 1.7 * k, 0.47 * d.B], bw);
  // radar mast + yard
  const mx = accX + 2 * k;
  const mt = F + accH + 5.5 * k;
  L.seg([mx, mt, 0], [mx, mt + 9 * k, 0], { kind: LINE.DARK, px: 0.9, world: 0.5 });
  L.seg([mx, mt + 6.5 * k, -4 * k], [mx, mt + 6.5 * k, 4 * k], { kind: LINE.DARK, px: 0.8, world: 0.35 });
  L.dot([mx, mt + 9.2 * k, 0], 2.6, LINE.GLOW);
  // forecastle mast and light
  const fmx = d.L / 2 - 9;
  L.seg([fmx, F + d.fc, 0], [fmx, F + d.fc + 12 * k, 0], { kind: LINE.DARK, px: 0.85, world: 0.45 });
  L.dot([fmx, F + d.fc + 12.3 * k, 0], 2.4, LINE.GLOW);
  // deck lights along the centreline, accommodation floods
  for (let x = ax + 40 * k; x < d.L / 2 - 20; x += 34) L.dot([x, F + 3, 0], 1.8, LINE.GLOW, 0.8);
  L.dot([accX + accW / 2 + 0.5, F + accH - 1, d.B * 0.3], 2.2, LINE.GLOW);
  L.dot([accX + accW / 2 + 0.5, F + accH - 1, -d.B * 0.3], 2.2, LINE.GLOW);
}

function tanker(b: MeshBuilder, L: LineBuilder, len: number): void {
  const d: Hull = { L: len, B: len / 6, F: 6.2, rake: 7, bowFrac: 0.16, fc: 2.4 };
  const k = len / 240;
  hull(b, L, d, 0.15, 0.4);
  superstructure(b, L, d, Math.max(k, 0.75));
  const F = d.F;
  // pipe rack (brass, as on the site's TankerArt), manifold, hose crane
  b.box(6, F, 0, len * 0.62, 1.3, 2.2, { tone: 0.42, brass: 0.35 });
  b.box(0, F, 0, 3.2 * k, 3.4, d.B * 0.6, { tone: 0.4, brass: 0.45 });
  b.box(9 * k, F, -d.B * 0.28, 1.3, 9, 1.3, { tone: 0.24 });
  b.box(d.L / 2 - 15, F + d.fc, 0, 6, 2.2, 8, { tone: 0.26 });
  L.seg([-d.L / 2 + 36 * k, F + 1.5, 0], [d.L / 2 - 26, F + 1.5, 0], { kind: LINE.BRASS, px: 0.9, world: 0.5 });
  L.seg([9 * k, F + 9, -d.B * 0.28], [22 * k, F + 6.5, -d.B * 0.1], { kind: LINE.DARK, px: 0.8, world: 0.4 });
  for (let x = -d.L / 2 + 40 * k; x < d.L / 2 - 30; x += 11) {
    L.seg([x, F, 0], [x, F + 1.4, 0], { kind: LINE.BRASS, px: 0.6, alpha: 0.7 });
  }
}

function gasCarrier(b: MeshBuilder, L: LineBuilder, len: number): void {
  const d: Hull = { L: len, B: len / 6, F: 5.6, rake: 5, bowFrac: 0.17, fc: 2.2 };
  const k = len / 240;
  hull(b, L, d, 0.16, 0.42);
  superstructure(b, L, d, Math.max(k * 1.15, 0.72));
  const F = d.F;
  // pressurised cargo tanks: horizontal cylinders on saddles
  const n = 4;
  const tl = (d.L * 0.62) / n;
  const r = d.B * 0.21;
  const x0 = -d.L / 2 + d.L * 0.25;
  for (let i = 0; i < n; i++) {
    const cx = x0 + tl * (i + 0.5);
    b.tank(cx, F + r + 1.2, 0, tl * 0.9, r, { tone: 0.66 }, 16);
    for (const sx of [-0.3, 0.3]) b.box(cx + sx * tl, F, 0, 1.6, 1.4 + r * 0.5, r * 1.5, { tone: 0.24 });
    b.dome(cx, F + 2 * r + 1.0, 0, r * 0.28, { tone: 0.3 }, 8, 3);
    L.seg([cx + tl * 0.32, F + 2 * r + 1, r * 0.4], [cx + tl * 0.32, F + 2 * r + 7.5, r * 0.4], { kind: LINE.DARK, px: 0.7, world: 0.3 });
  }
  L.seg([x0, F + 2 * r + 1.6, 0], [x0 + tl * n, F + 2 * r + 1.6, 0], { kind: LINE.BRASS, px: 0.9, world: 0.45 });
  L.seg([x0, F + 0.8, 0], [x0 + tl * n, F + 0.8, 0], { kind: LINE.BRASS, px: 0.7, alpha: 0.8 });
}

export function buildShips(b: MeshBuilder, L: LineBuilder, defs: ShipDef[]): void {
  defs.forEach((def, i) => {
    b.ship = i;
    L.ship = i;
    b.place = { x: 0, y: 0, z: 0 };
    if (def.type === "tanker") tanker(b, L, def.L);
    else gasCarrier(b, L, def.L);
  });
  b.ship = -1;
  L.ship = -1;
}
