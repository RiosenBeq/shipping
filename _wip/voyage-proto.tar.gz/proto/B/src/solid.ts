import * as THREE from "three";
import { GLSL_COMMON } from "./glsl";
import { GLSL_SHIP } from "./lines";
import type { Shared } from "./uniforms";

/**
 * One material for every solid (land curtains, landmarks, ships), drawn in a
 * single call. Ships are posed in the vertex shader from uniform arrays.
 * The fragment shader computes a tone (paint × fake light, aerial perspective)
 * and engraves it with world-anchored rules (latitude lines on domes, courses
 * on walls, planking on decks) plus cross-hatching in the darks.
 *
 * MIRROR variant: geometry flipped about the sea plane and drawn into the
 * low-res reflection target as plain tone + light (the sea engraves it).
 */
const VERT = /* glsl */ `
attribute vec4 aMat;
attribute vec4 aExt;
${GLSL_SHIP}
varying vec3 vW;
varying vec3 vN;
varying vec3 vL;
varying vec4 vMat;
varying vec4 vExt;
void main() {
  vec3 p = position;
  vec3 n = normal;
  vL = p;
  if (aExt.x > -0.5) {
    int si = int(aExt.x + 0.5);
    p = shipPoint(p, si);
    n = shipNormal(n, si);
  }
#ifdef MIRROR
  p.y = -p.y;
  n.y = -n.y;
#endif
  vW = p;
  vN = n;
  vMat = aMat;
  vExt = aExt;
  gl_Position = projectionMatrix * viewMatrix * vec4(p, 1.0);
}
`;

const FRAG = /* glsl */ `
uniform vec2 uRes;
uniform float uDpr;
uniform vec3 uCamPos;
uniform vec3 uKeyDir;
uniform vec4 uLightA;
uniform vec4 uFog;
uniform vec4 uHatch;
uniform float uLights;
uniform float uNight;
varying vec3 vW;
varying vec3 vN;
varying vec3 vL;
varying vec4 vMat;
varying vec4 vExt;
${GLSL_COMMON}
void main() {
  vec3 toCam = uCamPos - vW;
  float dist = length(toCam);
  vec3 V = toCam / dist;
  vec3 N = normalize(vN);
  if (dot(N, V) < 0.0) N = -N;
  float style = vMat.w;

  // ---- tone: paint × fake light ----
  float ndl = dot(N, uKeyDir);
  float lit = uLightA.x + uLightA.y * max(ndl, 0.0) + uLightA.z * max(N.y, 0.0);
  float tone = vMat.x;
  if (style > 1.5 && style < 2.5) {
    // hull: boot-top band at the waterline reads as a lighter engraved stripe
    tone += 0.32 * (1.0 - smoothstep(1.2, 1.9, vL.y)) * step(0.05, vL.y);
  }
  float t = tone * lit;
  // back-lit rim (silhouette edges catching the low sun)
  float rim = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 3.0) * max(dot(-V, uKeyDir), 0.0);
  t += rim * uLightA.w;
  float seed = vExt.z;
  if (style > 2.5) {
    // curtains: building blocks / tree masses vary the tone a little
    float blk = hash11(floor(vExt.w / mix(42.0, 14.0, vExt.y)) + seed * 13.0);
    t += (blk - 0.5) * mix(0.10, 0.16, vExt.y);
    t -= 0.10 * smoothstep(0.0, 1.0, (vW.y - 4.0) / 60.0) * (1.0 - vExt.y);
  }
  // aerial perspective: farther = lighter, toward the haze
  float F = (1.0 - exp(-dist / uFog.x)) * uFog.z;
  t = mix(clamp(t, 0.0, 1.0), uFog.y, F);

  // ---- lights (windows at night) ----
  float glow = vMat.z * uLights;
  vec2 wc = vec2(vExt.w / 6.5, vW.y / 3.6);
  float fpx = length(vec2(dFdx(wc.x), dFdy(wc.x)));
  if (style > 2.5 && vExt.y > 0.0 && uLights > 0.0) {
    vec2 cell = floor(wc);
    vec2 f = fract(wc);
    float on = step(1.0 - 0.33 * vExt.y * uHatch.w, hash12(cell + seed * 7.0));
    float win = on * step(0.3, f.x) * step(f.x, 0.72) * step(0.32, f.y) * step(f.y, 0.78);
    win = mix(win, 0.1 * vExt.y * uHatch.w, smoothstep(0.25, 0.8, fpx));
    glow += win * uLights * (1.0 - 0.6 * F) * step(2.0, vW.y);
  }

#ifdef MIRROR
  gl_FragColor = vec4(t, clamp(glow, 0.0, 1.0), 0.0, 1.0);
#else
  // ---- engraving ----
  float minPx = uHatch.x * uDpr;
  float v0;
  if (style > 0.5 && style < 1.5) v0 = vL.z / uHatch.y;          // deck planking
  else v0 = vW.y / uHatch.y;                                       // courses / latitudes
  float d = 1.0 - t;
  float ink = ruleInkLOD(v0, clamp(d * 1.04, 0.0, 1.0), minPx);
  // cross-hatching in the darks, on a diagonal anchored to the surface
  float along = style > 2.5 ? vExt.w : dot(vW.xz, vec2(0.7071, 0.7071));
  float v1 = (vW.y + 0.62 * along) / (uHatch.y * 1.4);
  float d2 = clamp((d - 0.5) * 1.6, 0.0, 1.0) * uHatch.z;
  float ink2 = ruleInkLOD(v1, d2, minPx * 1.15);
  ink = 1.0 - (1.0 - ink) * (1.0 - ink2);
  float lum = 1.0 - ink;
  // lit windows / lanterns read as light
  lum = mix(lum, 1.0, clamp(glow * 1.5, 0.0, 1.0));
  float brass = vMat.y * (1.0 - 0.55 * F);
  gl_FragColor = vec4(lum, max(brass, glow * 0.8), clamp(glow, 0.0, 1.0), depthCode(dist));
#endif
}
`;

export function createSolidMaterial(shared: Shared, mirror: boolean): THREE.ShaderMaterial {
  return new THREE.ShaderMaterial({
    uniforms: { ...shared },
    vertexShader: VERT,
    fragmentShader: FRAG,
    defines: mirror ? { MIRROR: "" } : {},
    side: THREE.DoubleSide,
  });
}
