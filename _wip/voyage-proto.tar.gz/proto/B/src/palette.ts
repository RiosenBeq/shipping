import * as THREE from "three";

/**
 * LEVANTER palette. Shaders work in display (sRGB) space and write it straight
 * to the canvas, so colours are plain 0..1 triples (no colour management).
 */
export const PAL = {
  navy: 0x0a1f33,
  navyDeep: 0x051624,
  navySoft: 0x13304a,
  brass: 0xb8893a,
  brassInk: 0x8a6420,
  brassLight: 0xd9b071,
  paper: 0xf3efe4,
  line: 0xe4ddcc,
  slate: 0x4a5e6e,
  fog: 0xa9b6bf,
  rose: 0xb98572,
} as const;

export function rgb(hex: number, out = new THREE.Vector3()): THREE.Vector3 {
  return out.set(((hex >> 16) & 255) / 255, ((hex >> 8) & 255) / 255, (hex & 255) / 255);
}

/** Linear blend of two hex colours into `out`. */
export function mixHex(a: number, b: number, t: number, out: THREE.Vector3): THREE.Vector3 {
  const ar = (a >> 16) & 255;
  const ag = (a >> 8) & 255;
  const ab = a & 255;
  const br = (b >> 16) & 255;
  const bg = (b >> 8) & 255;
  const bb = b & 255;
  return out.set((ar + (br - ar) * t) / 255, (ag + (bg - ag) * t) / 255, (ab + (bb - ab) * t) / 255);
}
