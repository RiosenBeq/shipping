import * as THREE from "three";

export const MAX_SHIPS = 8;

const v4s = (n: number, w = 0): THREE.Vector4[] => Array.from({ length: n }, () => new THREE.Vector4(0, 0, 0, w));

/**
 * Uniform objects shared (by reference) between every material, so one write
 * per frame updates the whole plate.
 */
export function createShared() {
  return {
    uTime: { value: 0 },
    uRes: { value: new THREE.Vector2(1, 1) },
    uDpr: { value: 1 },
    uCamPos: { value: new THREE.Vector3(0, 10, 0) },
    uFwd: { value: new THREE.Vector3(0, 0, -1) },
    uRight: { value: new THREE.Vector3(1, 0, 0) },
    /** x tanH, y top (tan units, view-space y at unit depth), z bottom, w unused. */
    uFrustum: { value: new THREE.Vector4(0.5, 0.2, -0.1, 0) },
    uNearFar: { value: new THREE.Vector2(0.5, 60000) },
    /** Key light direction for objects (sun by day, moon by night). */
    uKeyDir: { value: new THREE.Vector3(0, 1, 0) },
    /** x ambient, y diffuse, z sky light (up-facing), w back-light rim. */
    uLightA: { value: new THREE.Vector4(0.4, 0.6, 0.2, 0.2) },
    /** x fog distance (m), y haze tone, z fog max, w calm-area strength. */
    uFog: { value: new THREE.Vector4(4000, 0.85, 0.9, 0) },
    uLights: { value: 0 },
    uNight: { value: 0 },
    /** x min rule spacing (CSS px), y world rule spacing (m), z cross-hatch, w window density. */
    uHatch: { value: new THREE.Vector4(2.6, 0.3, 0.6, 1) },
    /** Ship pose: x, z, heading (rad), heave (m). */
    uShipPose: { value: v4s(MAX_SHIPS) },
    /** Ship motion: pitch, roll (rad), scale (0 hides), lights 0..1. */
    uShipMot: { value: v4s(MAX_SHIPS, 0) },
    /** Ship wake: length, beam, speed factor, foam. */
    uShipWake: { value: v4s(MAX_SHIPS) },
  };
}

export type Shared = ReturnType<typeof createShared>;
