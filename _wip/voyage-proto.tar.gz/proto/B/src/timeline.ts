import { SCENES } from "../../contract";
import { clamp, lerp, smootherstep, smoothstep } from "./math";

/**
 * The journey: five held keyframes (contract SCENES) and the flights between.
 * World: metres, x east, z south (north = −z), y up; heading in degrees
 * clockwise from north. The camera is always level (verticals stay vertical,
 * like a view camera); the horizon is placed with a lens shift, so
 * `horizon` is exactly the fraction of the frame height above the sea line.
 */
export interface Cam {
  x: number;
  y: number;
  z: number;
  heading: number;
  /** Horizontal field of view, degrees. */
  hfov: number;
  /** Horizon position, fraction of height from the top. */
  horizon: number;
}

/** Portrait framing: heading offset and absolute hfov / horizon. */
export interface CamMobile {
  dHeading: number;
  hfov: number;
  horizon: number;
  dx: number;
  dz: number;
}

export interface Look {
  night: number;
  lineLum: number;
  ground: number;
  skyH: number;
  skyT: number;
  skyFade: number;
  skyLine: number;
  warm: number;
  afterglow: number;
  stars: number;
  lights: number;
  sunAz: number;
  sunEl: number;
  sunR: number;
  sunVis: number;
  sunRings: number;
  sunGlow: number;
  sunBrass: number;
  moonAz: number;
  moonEl: number;
  moonR: number;
  moonVis: number;
  seaDeep: number;
  seaRefl: number;
  seaK: number;
  swell: number;
  glitter: number;
  foam: number;
  reflAmt: number;
  haze: number;
  fogDist: number;
  fogMax: number;
  amb: number;
  diff: number;
  skyLight: number;
  rim: number;
  keyAz: number;
  keyEl: number;
  cloud: number;
  cloudX: number;
  cloudY: number;
  cloudW: number;
  cloudH: number;
  cloudScale: number;
  cloudHeight: number;
  cloudStep: number;
  calm: number;
  calmX: number;
  calmY: number;
  calmW: number;
  calmH: number;
  calmMX: number;
  calmMY: number;
  calmMW: number;
  calmMH: number;
  gulls: number;
  edge: number;
  vignette: number;
  bleed: number;
}

export interface Key {
  cam: Cam;
  mob: CamMobile;
  look: Look;
  /** Gull flock in frame coordinates: [x, y (from top), size CSS px]. */
  gulls: [number, number, number][];
}

/** A flight between two keyframes: Bézier control points and a height lift. */
interface Flight {
  via: [number, number, number][];
  lift: number;
}

const HERO: Look = {
  night: 0,
  lineLum: 0,
  ground: 1,
  skyH: 0.8,
  skyT: 1,
  skyFade: 7,
  skyLine: 3.3,
  warm: 0.6,
  afterglow: 0,
  stars: 0,
  lights: 0,
  sunAz: 13,
  sunEl: 7.2,
  sunR: 25,
  sunVis: 1,
  sunRings: 1,
  sunGlow: 0.75,
  sunBrass: 0.7,
  moonAz: 200,
  moonEl: -20,
  moonR: 16,
  moonVis: 0,
  seaDeep: 0.36,
  seaRefl: 0.9,
  seaK: 42,
  swell: 0.42,
  glitter: 1,
  foam: 0.45,
  reflAmt: 0.65,
  haze: 0.86,
  fogDist: 2600,
  fogMax: 0.93,
  amb: 0.42,
  diff: 0.28,
  skyLight: 0.2,
  rim: 0.55,
  keyAz: 13,
  keyEl: 7.2,
  cloud: 0.75,
  cloudX: 0.8,
  cloudY: 0.28,
  cloudW: 0.32,
  cloudH: 0.2,
  cloudScale: 0.0011,
  cloudHeight: 1500,
  cloudStep: 0.11,
  calm: 1,
  calmX: 0.3,
  calmY: 0.42,
  calmW: 0.36,
  calmH: 0.34,
  calmMX: 0.45,
  calmMY: 0.45,
  calmMW: 0.7,
  calmMH: 0.34,
  gulls: 1,
  edge: 0.75,
  vignette: 0.32,
  bleed: 0.32,
};

const DESKS: Look = {
  ...HERO,
  skyH: 0.84,
  skyFade: 6,
  warm: 0.25,
  sunAz: 250,
  sunEl: 32,
  sunR: 24,
  sunGlow: 0.5,
  seaDeep: 0.34,
  seaK: 36,
  swell: 0.75,
  glitter: 0.6,
  foam: 0.9,
  reflAmt: 0.5,
  fogDist: 3600,
  amb: 0.42,
  diff: 0.55,
  skyLight: 0.25,
  rim: 0.15,
  keyAz: 250,
  keyEl: 32,
  cloud: 0.65,
  cloudX: 0.78,
  cloudY: 0.18,
  cloudW: 0.3,
  cloudH: 0.13,
  calmX: 0.3,
  calmY: 0.21,
  calmW: 0.34,
  calmH: 0.17,
  calmMX: 0.45,
  calmMY: 0.22,
  calmMW: 0.7,
  calmMH: 0.18,
};

const STRAITS: Look = {
  ...HERO,
  skyH: 0.7,
  skyT: 0.99,
  skyFade: 9,
  warm: 0.9,
  sunAz: -17,
  sunEl: 4.6,
  sunR: 29,
  sunGlow: 0.85,
  sunBrass: 0.85,
  seaDeep: 0.32,
  seaK: 40,
  swell: 0.4,
  glitter: 1.5,
  foam: 0.45,
  reflAmt: 0.7,
  haze: 0.8,
  fogDist: 2300,
  amb: 0.36,
  diff: 0.3,
  rim: 0.75,
  keyAz: -17,
  keyEl: 4.6,
  cloud: 0.55,
  cloudX: 0.8,
  cloudY: 0.26,
  cloudW: 0.3,
  cloudH: 0.18,
  calmX: 0.3,
  calmY: 0.21,
  calmW: 0.34,
  calmH: 0.17,
  calmMX: 0.45,
  calmMY: 0.22,
  calmMW: 0.7,
  calmMH: 0.18,
  gulls: 0.8,
};

const PROCESS: Look = {
  ...STRAITS,
  night: 0.75,
  lineLum: 1,
  ground: 0.04,
  skyH: 0.52,
  skyT: 0.05,
  skyFade: 12,
  warm: 0,
  afterglow: 0.85,
  stars: 0.55,
  lights: 0.9,
  sunAz: -55,
  sunEl: -6,
  sunVis: 0,
  sunGlow: 0,
  sunRings: 0,
  seaDeep: 0.05,
  seaRefl: 0.95,
  swell: 0.35,
  glitter: 0.35,
  foam: 0.2,
  reflAmt: 0.85,
  haze: 0.36,
  fogDist: 3600,
  fogMax: 0.75,
  amb: 0.12,
  diff: 0.06,
  skyLight: 0.12,
  rim: 0.25,
  keyAz: -55,
  keyEl: 8,
  cloud: 0.3,
  cloudX: 0.75,
  cloudY: 0.18,
  calm: 0,
  gulls: 0,
  edge: 0.35,
  vignette: 0.45,
};

const CONTACT: Look = {
  ...PROCESS,
  night: 1,
  skyH: 0.26,
  skyT: 0.035,
  skyFade: 14,
  afterglow: 0,
  stars: 1,
  lights: 1,
  moonAz: 207,
  moonEl: 13,
  moonR: 17,
  moonVis: 1,
  seaDeep: 0.03,
  glitter: 1.1,
  foam: 0.25,
  haze: 0.22,
  fogDist: 3000,
  amb: 0.1,
  diff: 0.2,
  skyLight: 0.06,
  rim: 0.3,
  keyAz: 207,
  keyEl: 13,
  cloud: 0.45,
  cloudX: 0.62,
  cloudY: 0.22,
  cloudW: 0.34,
  cloudH: 0.16,
  calm: 1,
  calmX: 0.3,
  calmY: 0.5,
  calmW: 0.36,
  calmH: 0.26,
  calmMX: 0.45,
  calmMY: 0.5,
  calmMW: 0.7,
  calmMH: 0.28,
  edge: 0.3,
};

export const KEYS: Key[] = [
  {
    cam: { x: 250, y: 8, z: 1600, heading: -6, hfov: 58, horizon: 0.64 },
    mob: { dHeading: 14, hfov: 40, horizon: 0.68, dx: 0, dz: 0 },
    look: HERO,
    gulls: [
      [0.62, 0.3, 13],
      [0.67, 0.25, 10],
      [0.7, 0.33, 9],
      [0.58, 0.22, 8],
      [0.74, 0.27, 7],
      [0.66, 0.37, 7],
    ],
  },
  {
    cam: { x: 2000, y: 30, z: 5600, heading: -145, hfov: 56, horizon: 0.4 },
    mob: { dHeading: 8, hfov: 36, horizon: 0.42, dx: 0, dz: 0 },
    look: DESKS,
    gulls: [
      [0.84, 0.16, 12],
      [0.9, 0.12, 9],
      [0.78, 0.1, 8],
      [0.95, 0.2, 7],
      [0.72, 0.2, 7],
      [0.88, 0.24, 6],
    ],
  },
  {
    cam: { x: -150, y: 10, z: -2000, heading: -8, hfov: 64, horizon: 0.6 },
    mob: { dHeading: 6, hfov: 40, horizon: 0.6, dx: 0, dz: 0 },
    look: STRAITS,
    gulls: [
      [0.66, 0.24, 11],
      [0.71, 0.2, 8],
      [0.6, 0.3, 8],
      [0.76, 0.28, 7],
      [0.55, 0.22, 6],
      [0.69, 0.33, 6],
    ],
  },
  {
    cam: { x: -1600, y: 20, z: 4800, heading: -4, hfov: 38, horizon: 0.6 },
    mob: { dHeading: 4, hfov: 26, horizon: 0.58, dx: 0, dz: 0 },
    look: PROCESS,
    gulls: [
      [0.7, 0.2, 0],
      [0.75, 0.15, 0],
      [0.8, 0.2, 0],
      [0.72, 0.25, 0],
      [0.78, 0.12, 0],
      [0.82, 0.26, 0],
    ],
  },
  {
    cam: { x: 641, y: 6, z: 547, heading: -155, hfov: 58, horizon: 0.6 },
    mob: { dHeading: 10, hfov: 38, horizon: 0.6, dx: 0, dz: 0 },
    look: CONTACT,
    gulls: [
      [0.7, 0.2, 0],
      [0.75, 0.15, 0],
      [0.8, 0.2, 0],
      [0.72, 0.25, 0],
      [0.78, 0.12, 0],
      [0.82, 0.26, 0],
    ],
  },
];

const FLIGHTS: Flight[] = [
  { via: [[700, 30, 3200]], lift: 45 },
  { via: [[-350, 60, 1900]], lift: 35 },
  { via: [[-200, 40, 1200]], lift: 40 },
  { via: [[100, 40, 2900]], lift: 30 },
];

/** Hold each keyframe for a little scroll before the camera departs. */
const HOLD = 0.07;

export interface Frame {
  x: number;
  y: number;
  z: number;
  heading: number;
  hfov: number;
  horizon: number;
  look: Look;
  gulls: [number, number, number][];
  /** 1 = portrait framing. */
  portrait: number;
  /** Segment index and eased local parameter (for ambient choreography). */
  seg: number;
  e: number;
}

function lerpLook(a: Look, b: Look, t: number): Look {
  const out = { ...a };
  for (const k of Object.keys(a) as (keyof Look)[]) out[k] = lerp(a[k], b[k], t);
  return out;
}

function bezier(pts: [number, number, number][], t: number): [number, number, number] {
  let p = pts.map((q) => [...q] as [number, number, number]);
  while (p.length > 1) {
    const next: [number, number, number][] = [];
    for (let i = 0; i < p.length - 1; i++) {
      next.push([lerp(p[i][0], p[i + 1][0], t), lerp(p[i][1], p[i + 1][1], t), lerp(p[i][2], p[i + 1][2], t)]);
    }
    p = next;
  }
  return p[0];
}

function camFor(k: Key, portrait: number): Cam {
  const c = k.cam;
  const m = k.mob;
  return {
    x: c.x + m.dx * portrait,
    y: c.y,
    z: c.z + m.dz * portrait,
    heading: c.heading + m.dHeading * portrait,
    hfov: lerp(c.hfov, m.hfov, portrait),
    horizon: lerp(c.horizon, m.horizon, portrait),
  };
}

/** Exact frame for progress p (0..1) and viewport aspect (w / h). */
export function evaluate(progress: number, aspect: number): Frame {
  const p = clamp(progress, 0, 1);
  const portrait = 1 - smoothstep(0.7, 1.25, aspect);
  let i = 0;
  while (i < SCENES.length - 2 && p > SCENES[i + 1].at) i++;
  const a = SCENES[i].at;
  const b = SCENES[i + 1].at;
  const s = clamp((p - a) / (b - a), 0, 1);
  const e = smootherstep((s - HOLD) / (1 - 2 * HOLD));
  const k0 = KEYS[i];
  const k1 = KEYS[i + 1];
  const c0 = camFor(k0, portrait);
  const c1 = camFor(k1, portrait);
  const fl = FLIGHTS[i];
  const pos = bezier([[c0.x, c0.y, c0.z], ...fl.via, [c1.x, c1.y, c1.z]], e);
  const lift = fl.lift * Math.sin(Math.PI * e);
  const look = lerpLook(k0.look, k1.look, e);
  const gulls = k0.gulls.map((g, j) => {
    const h = k1.gulls[j];
    return [lerp(g[0], h[0], e), lerp(g[1], h[1], e), lerp(g[2], h[2], e)] as [number, number, number];
  });
  // portrait layouts: the copy spans the width, so the calm zone does too
  look.calmX = lerp(look.calmX, look.calmMX, portrait);
  look.calmY = lerp(look.calmY, look.calmMY, portrait);
  look.calmW = lerp(look.calmW, look.calmMW, portrait);
  look.calmH = lerp(look.calmH, look.calmMH, portrait);
  return {
    x: pos[0],
    y: Math.max(pos[1] + lift, 2),
    z: pos[2],
    heading: lerp(c0.heading, c1.heading, e),
    hfov: lerp(c0.hfov, c1.hfov, e),
    horizon: lerp(c0.horizon, c1.horizon, e),
    look,
    gulls,
    portrait,
    seg: i,
    e,
  };
}
