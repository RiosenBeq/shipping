/**
 * Shared GLSL for the engraving look.
 *
 * Every surface is turned into line work by the same few primitives:
 *  - ruleInk:     box-filtered parallel rules whose width encodes tone. Exact
 *                 1-px box filter (coverage-preserving), so lines never shimmer;
 *                 when rules get denser than ~2 px they fold into their mean tone.
 *  - ruleInkLOD:  the same for world-anchored rules, with octave blending
 *                 (every other rule fades out) to keep the on-screen spacing in
 *                 [minPx, 2·minPx] at any distance and DPR — a tonal-art-map.
 *  - dashCov:     exact box-filtered periodic dashes (broken / fading rules).
 *  - stippleLum:  stochastic dot screen for foam.
 * Render targets carry abstract channels, coloured once in the post pass:
 *   R = luminance coverage (0 dark ink .. 1 light ground), G = brass,
 *   B = emitted light (halation), A = log-depth code (outline detection).
 */
export const GLSL_COMMON = /* glsl */ `
float hash11(float p) { p = fract(p * 0.1031); p *= p + 33.33; p *= p + p; return fract(p); }
float hash12(vec2 p) { vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
vec2 hash22(vec2 p) { vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973)); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.xx + p3.yz) * p3.zy); }

float vnoise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  float a = hash12(i);
  float b = hash12(i + vec2(1.0, 0.0));
  float c = hash12(i + vec2(0.0, 1.0));
  float d = hash12(i + vec2(1.0, 1.0));
  return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float fbm3(vec2 p) {
  float s = 0.5 * vnoise(p);
  p = p * 2.03 + 17.1;
  s += 0.25 * vnoise(p);
  p = p * 2.01 + 7.3;
  s += 0.125 * vnoise(p);
  return s / 0.875;
}

/* Exact coverage of a line of half-width hw (px) by a 1-px box pixel at distance dist (px). */
float lineBox(float dist, float hw) {
  return clamp(min(hw, dist + 0.5) - max(-hw, dist - 0.5), 0.0, 1.0);
}

/* Parallel rules at integer v. d = ink fraction (0..1), fw = |grad v| (rules per px). */
float ruleInk(float v, float d, float fw) {
  float sp = 1.0 / max(fw, 1e-4);
  float dist = abs(fract(v + 0.5) - 0.5) * sp;
  float hw = 0.5 * d * sp;
  float ink = min(1.0, lineBox(dist, hw) + lineBox(sp - dist, hw));
  return mix(ink, d, smoothstep(0.32, 0.55, fw));
}

/* Box-filtered periodic dashes: fraction of a 1-px footprint covered by dashes of
   duty 'duty' (period 1 in u). fu = du per px. */
float dashF(float x, float duty) { return floor(x) * duty + min(fract(x), duty); }
float dashCov(float u, float duty, float fu) {
  float w = max(fu, 1e-4);
  return clamp((dashF(u + 0.5 * w, duty) - dashF(u - 0.5 * w, duty)) / w, 0.0, 1.0);
}

/* Rules that break into dashes instead of thinning below dMin (engraver's fade).
   Symmetric: on dark ground the light rules (the minority) are the ones that break. */
float ruleInkB(float v, float u, float d, float fw, float fu, float dMin) {
  float darkG = step(0.5, d);
  float m = mix(d, 1.0 - d, darkG);
  float mm = max(m, dMin);
  float vv = v + 0.5 * darkG;
  float sp = 1.0 / max(fw, 1e-4);
  float dist = abs(fract(vv + 0.5) - 0.5) * sp;
  float hw = 0.5 * mm * sp;
  float line = min(1.0, lineBox(dist, hw) + lineBox(sp - dist, hw));
  float duty = clamp(m / dMin, 0.0, 1.0);
  float li = floor(vv + 0.5);
  float uu = u * (0.75 + 0.5 * hash11(li * 1.37 + 0.5)) + hash11(li + 11.0) * 17.0;
  line *= dashCov(uu, duty, fu);
  line = mix(line, m, smoothstep(0.32, 0.55, fw));
  return mix(line, 1.0 - line, darkG);
}

/* Rules on a world/perspective coordinate with octave LOD. Below lev -1 the
   natural spacing is kept (bold foreground rules). */
float ruleInkLOD(float v0, float d, float minPx) {
  float fw0 = max(length(vec2(dFdx(v0), dFdy(v0))), 1e-6);
  float lev = log2(fw0 * minPx);
  float L = max(floor(lev) + 1.0, 0.0);
  float fr = lev < -1.0 ? 0.0 : fract(lev);
  float s0 = exp2(-L);
  float a = ruleInk(v0 * s0, d, fw0 * s0);
  float b = ruleInk(v0 * s0 * 0.5, d, fw0 * s0 * 0.5);
  return mix(a, b, fr);
}

/* Log distance → 0..0.97 (sea and sky write 1.0). */
float depthCode(float dist) { return clamp(log2(max(dist, 1.0)) / 15.5, 0.0, 0.97); }

/* Stochastic dot screen; returns luminance with mean ≈ t. cell in px. */
float stippleLum(vec2 px, float t, float cell) {
  vec2 g = px / cell;
  vec2 c = floor(g);
  vec2 f = g - c;
  vec2 h = hash22(c);
  vec2 ctr = 0.28 + 0.44 * h;
  float darkDots = step(0.5, t);
  float a = mix(t, 1.0 - t, darkDots);
  float r = sqrt(a / 3.14159) * (0.7 + 0.6 * hash12(c + 7.31));
  r = min(r, 0.45);
  float dist = length(f - ctr) * cell;
  float cov = clamp(r * cell - dist + 0.5, 0.0, 1.0);
  return mix(cov, 1.0 - cov, darkDots);
}
`;
