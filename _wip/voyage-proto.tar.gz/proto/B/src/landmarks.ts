import { MeshBuilder, STYLE, type Place } from "./geometry";
import { LINE, LineBuilder } from "./lines";
import { lerp, type V3 } from "./math";

/**
 * Istanbul landmarks, modelled for an engraver's eye: correct proportions,
 * crisp silhouettes, minarets as pencil-thin hairlines with conical caps.
 * Everything is placed in world metres (x east, z south).
 */

function W(pl: Place, x: number, y: number, z: number): V3 {
  const s = pl.s ?? 1;
  const yaw = pl.yaw ?? 0;
  const c = Math.cos(yaw);
  const sn = Math.sin(yaw);
  return [pl.x + (x * c + z * sn) * s, pl.y + y * s, pl.z + (-x * sn + z * c) * s];
}

export interface MosqueSpec {
  x: number;
  z: number;
  y0: number;
  /** Main dome radius (m). */
  R: number;
  minarets: number;
  yaw?: number;
  semi?: boolean;
  /** Minaret height as a multiple of R. */
  minH?: number;
  tone?: number;
}

/** A pencil minaret: shaft, one to three balconies, sharp conical cap. */
export function minaret(L: LineBuilder, base: V3, h: number, r: number, balconies: number): void {
  const [x, y, z] = base;
  const capStart = y + h * 0.84;
  L.seg([x, y, z], [x, capStart, z], { kind: LINE.DARK, px: 1.0, world: 2 * r });
  L.seg([x, capStart, z], [x, y + h, z], { kind: LINE.DARK, px: 1.1, pxB: 0.25, world: 2.3 * r, worldB: 0.1 });
  for (let k = 0; k < balconies; k++) {
    const hb = y + h * (0.6 + 0.11 * k);
    L.seg([x, hb - 0.5, z], [x, hb + 0.9, z], { kind: LINE.DARK, px: 2.0, world: 3.4 * r });
  }
}

export function mosque(b: MeshBuilder, L: LineBuilder, m: MosqueSpec): void {
  const R = m.R;
  const pl: Place = { x: m.x, y: m.y0, z: m.z, yaw: m.yaw ?? 0 };
  b.place = pl;
  const stone = { tone: m.tone ?? 0.64 };
  const lead = { tone: 0.46 };
  // prayer hall, weight turrets, drum, dome
  b.box(0, -30, 0, 2.5 * R, 30 + 0.95 * R, 2.5 * R, stone);
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      b.box(sx * 1.02 * R, 0.95 * R - 0.02, sz * 1.02 * R, 0.4 * R, 0.32 * R, 0.4 * R, stone);
      b.dome(sx * 1.02 * R, 1.27 * R, sz * 1.02 * R, 0.17 * R, lead, 8, 3, 1.4);
    }
  }
  b.cyl(0, 0.93 * R, 0, 0.98 * R, 0.98 * R, 0.24 * R, stone, 18, false);
  b.dome(0, 1.17 * R, 0, R, lead, 20, 7);
  if (m.semi) {
    b.dome(0, 0.7 * R, 1.1 * R, 0.66 * R, lead, 14, 5);
    b.dome(0, 0.7 * R, -1.1 * R, 0.66 * R, lead, 14, 5);
  }
  // portico with a row of small domes
  b.box(0, -12, 2.15 * R, 2.3 * R, 12 + 0.42 * R, 1.7 * R, stone);
  for (let k = -2; k <= 2; k++) b.dome(k * 0.46 * R, 0.42 * R, 2.15 * R, 0.19 * R, lead, 8, 3);
  // finial
  L.seg(W(pl, 0, 2.17 * R, 0), W(pl, 0, 2.17 * R + 0.35 * R, 0), { kind: LINE.DARK, px: 0.8, world: 0.6 });
  // minarets
  const H = (m.minH ?? 4.4) * R;
  const r = 0.15 * R;
  const spots: [number, number][] =
    m.minarets === 1
      ? [[1.45, 1.45]]
      : m.minarets === 2
        ? [
            [-1.45, 1.3],
            [1.45, 1.3],
          ]
        : m.minarets === 4
          ? [
              [-1.45, -1.45],
              [1.45, -1.45],
              [-1.45, 1.45],
              [1.45, 1.45],
            ]
          : [
              [-1.45, -1.45],
              [1.45, -1.45],
              [-1.45, 1.45],
              [1.45, 1.45],
              [-1.35, 3.2],
              [1.35, 3.2],
            ];
  spots.forEach(([sx, sz], i) => {
    const base = W(pl, sx * R, 0.2 * R, sz * R);
    const tall = m.minarets >= 4 && i < 4 ? 1 : 0.86;
    minaret(L, [base[0], m.y0 - 4, base[2]], H * tall + 0.2 * R + 4, r, m.minarets >= 4 ? 3 : 2);
  });
}

export function galata(b: MeshBuilder, L: LineBuilder, x: number, z: number, y0: number): void {
  b.place = { x, y: 0, z };
  b.dome(0, -2, 0, 240, { tone: 0.5, style: STYLE.CURTAIN }, 18, 5, (y0 + 2) / 240);
  const pl: Place = { x, y: y0, z };
  b.place = pl;
  b.cyl(0, -8, 0, 9.8, 8.8, 48, { tone: 0.66 }, 18, false);
  b.cyl(0, 40, 0, 10.8, 10.8, 1.5, { tone: 0.3 }, 18, true);
  b.cyl(0, 41.5, 0, 8.6, 8.3, 6.5, { tone: 0.64 }, 18, false);
  b.cyl(0, 48, 0, 9.4, 0.25, 18, { tone: 0.3 }, 18, false);
  L.seg(W(pl, 0, 66, 0), W(pl, 0, 70.5, 0), { kind: LINE.DARK, px: 0.8, world: 0.5 });
  // gallery windows
  const ring: V3[] = [];
  for (let i = 0; i <= 24; i++) {
    const a = (i / 24) * Math.PI * 2;
    ring.push(W(pl, Math.cos(a) * 8.75, 44.2, Math.sin(a) * 8.75));
  }
  L.poly(ring, { kind: LINE.WINDOW, px: 1.2, world: 1.6, dash: 2.6, duty: 0.45 });
  const ring2: V3[] = ring.map((p) => [p[0], p[1] - 14, p[2]] as V3);
  L.poly(ring2, { kind: LINE.WINDOW, px: 0.9, world: 1.4, dash: 5.5, duty: 0.25 });
}

export function maidensTower(b: MeshBuilder, L: LineBuilder, x: number, z: number): void {
  const pl: Place = { x, y: 0, z, yaw: 0.35, s: 1.35 };
  b.place = pl;
  b.dome(0, -1.6, 0, 31, { tone: 0.2 }, 18, 3, 0.13);
  b.box(0, 0, 0, 46, 2.6, 22, { tone: 0.46 });
  b.box(-7, 2.6, 0, 26, 8, 14, { tone: 0.76 });
  b.box(-7, 10.6, 0, 26, 2.4, 14, { tone: 0.34 }, 0.7);
  b.box(9, 2.6, 0, 10, 15, 10, { tone: 0.74 });
  b.box(9, 17.6, 0, 11.2, 0.9, 11.2, { tone: 0.32 });
  b.cyl(9, 18.5, 0, 4.4, 4.2, 9.5, { tone: 0.74 }, 8, false);
  b.cyl(9, 28, 0, 5.5, 5.5, 0.8, { tone: 0.3 }, 8, true);
  b.cyl(9, 28.8, 0, 3.9, 3.9, 2.3, { tone: 0.72 }, 8, false);
  b.dome(9, 31.1, 0, 4.3, { tone: 0.3 }, 12, 5, 1.55);
  b.cyl(9, 37.5, 0, 0.9, 0.7, 2.4, { tone: 0.4, glow: 0.7 }, 8, true);
  L.seg(W(pl, 9, 39.9, 0), W(pl, 9, 47, 0), { kind: LINE.DARK, px: 0.7, world: 0.25 });
  L.seg(W(pl, 9, 46.8, 0), W(pl, 13.2, 45.6, 0), { kind: LINE.DARK, px: 1.4, pxB: 0.6, world: 1.6 });
  // windows: hall rows, tower bays (paper dashes by day, lit at night)
  const win = { kind: LINE.WINDOW, px: 1.1, world: 1.1, dash: 3.2, duty: 0.42 };
  for (const y of [5.2, 8.4]) {
    L.seg(W(pl, -19.5, y, 7.05), W(pl, 5.5, y, 7.05), win);
    L.seg(W(pl, -19.5, y, -7.05), W(pl, 5.5, y, -7.05), win);
    L.seg(W(pl, -20.05, y, -6), W(pl, -20.05, y, 6), win);
  }
  const tw = { kind: LINE.WINDOW, px: 1.2, world: 1.2, dash: 3.3, duty: 0.4 };
  for (const y of [7, 11, 14.8]) {
    L.seg(W(pl, 4.6, y, 5.05), W(pl, 13.4, y, 5.05), tw);
    L.seg(W(pl, 4.6, y, -5.05), W(pl, 13.4, y, -5.05), tw);
    L.seg(W(pl, 14.05, y, -4.4), W(pl, 14.05, y, 4.4), tw);
    L.seg(W(pl, 3.95, y, -4.4), W(pl, 3.95, y, 4.4), tw);
  }
  const oct: V3[] = [];
  for (let i = 0; i <= 8; i++) {
    const a = (i / 8) * Math.PI * 2 + Math.PI / 8;
    oct.push(W(pl, 9 + Math.cos(a) * 4.32, 22.5, Math.sin(a) * 4.32));
  }
  L.poly(oct, { kind: LINE.WINDOW, px: 1.3, world: 1.6, dash: 3.4, duty: 0.33 });
  L.dot(W(pl, 9, 38.6, 0), 3.4, LINE.BEACON);
  L.dot(W(pl, 22, 3.6, 10), 2.2, LINE.GLOW);
  L.dot(W(pl, -22, 3.6, -10), 2.2, LINE.GLOW);
}

export const BRIDGE = { z: -3420, xA: -807, xB: 267, deck: 70, top: 200 } as const;

export function bridge(b: MeshBuilder, L: LineBuilder): void {
  const { z, xA, xB, deck, top } = BRIDGE;
  const tone = { tone: 0.6 };
  for (const xt of [xA, xB]) {
    b.place = { x: xt, y: 0, z };
    for (const sz of [-1, 1]) b.box(0, -12, sz * 17, 8.5, top + 12, 7.5, tone, 0.7);
    b.box(0, deck - 8, 0, 7, 5, 40, tone);
    b.box(0, (deck + top) / 2 - 2, 0, 6, 4.5, 36, tone);
    b.box(0, top - 7, 0, 6.5, 6, 32, tone);
  }
  b.place = { x: 0, y: 0, z };
  b.box((xA + xB) / 2, deck - 3.8, 0, xB - xA + 1000, 3.8, 33, { tone: 0.36 });
  const span = xB - xA;
  const cable = (x: number): number => {
    if (x < xA) return lerp(deck + 3, top, Math.pow((x - (xA - 360)) / 360, 1.25));
    if (x > xB) return lerp(deck + 3, top, Math.pow((xB + 360 - x) / 360, 1.25));
    const u = ((x - xA) / span) * 2 - 1;
    return top - (top - deck - 4) * (1 - u * u);
  };
  for (const sz of [-16.5, 16.5]) {
    const pts: V3[] = [];
    for (let k = 0; k <= 72; k++) {
      const x = lerp(xA - 360, xB + 360, k / 72);
      pts.push([x, cable(x), z + sz]);
    }
    L.poly(pts, { kind: LINE.DARK, px: 1.05, world: 0.9 });
    // inclined hangers: the bridge's signature zig-zag
    for (let k = 1; k < 60; k++) {
      const x = lerp(xA, xB, k / 60);
      const lean = (k % 2 ? 1 : -1) * 8;
      L.seg([x, cable(x), z + sz], [x + lean, deck - 0.5, z + sz], { kind: LINE.DARK, px: 0.5, alpha: 0.7, world: 0.12 });
    }
    // deck edge highlight
    L.seg([xA - 480, deck - 0.2, z + sz], [xB + 480, deck - 0.2, z + sz], { kind: LINE.LIGHT, px: 0.7, alpha: 0.75 });
  }
}

export function palace(b: MeshBuilder, L: LineBuilder): void {
  const pl: Place = { x: -955, y: 0, z: -2000, yaw: Math.PI / 2 };
  b.place = pl;
  const marble = { tone: 0.82 };
  b.box(0, 0, 0, 600, 19, 26, marble);
  b.box(0, 19, 0, 604, 2.2, 28, { tone: 0.42 });
  b.box(40, 0, 0, 92, 31, 32, marble);
  b.dome(40, 31, 0, 13, { tone: 0.5 }, 14, 5, 0.65);
  for (const px of [-282, 282]) b.box(px, 0, 0, 38, 24, 30, marble);
  const win = { kind: LINE.WINDOW, px: 1.0, world: 1.4, dash: 5.5, duty: 0.38 };
  for (const y of [5.5, 12.5]) L.seg(W(pl, -296, y, 13.2), W(pl, 296, y, 13.2), win);
  L.seg(W(pl, -6, 17, 16.2), W(pl, 86, 17, 16.2), { ...win, dash: 4, duty: 0.5 });
  L.seg(W(pl, -300, 1.6, 13.4), W(pl, 300, 1.6, 13.4), { kind: LINE.DARK, px: 0.8, dash: 7, duty: 0.6, alpha: 0.7 });
}

/** Topkapı: the Tower of Justice over low palace roofs on Seraglio Point. */
export function topkapi(b: MeshBuilder, L: LineBuilder): void {
  const pl: Place = { x: -1180, y: 30, z: 1180, yaw: 0.6 };
  b.place = pl;
  b.box(0, -30, 0, 12, 30 + 30, 12, { tone: 0.66 });
  b.box(0, 30, 0, 13.5, 1.2, 13.5, { tone: 0.32 });
  b.cyl(0, 31.2, 0, 6.8, 0.3, 17, { tone: 0.3 }, 8, false);
  L.seg(W(pl, 0, 48, 0), W(pl, 0, 52, 0), { kind: LINE.DARK, px: 0.8 });
  b.box(-60, -20, 25, 110, 20 + 11, 30, { tone: 0.62 }, 0.92);
  b.box(70, -20, -10, 80, 20 + 9, 26, { tone: 0.6 }, 0.92);
  for (let k = 0; k < 6; k++) b.dome(-95 + k * 16, 11, 25, 5, { tone: 0.46 }, 10, 3);
}
