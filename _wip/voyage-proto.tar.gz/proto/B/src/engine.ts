import * as THREE from "three";
import type { Voyage, VoyageInfo, VoyageOptions, VoyageQuality } from "../../contract";
import { createBackdrop } from "./backdrop";
import { createLineMaterial } from "./lines";
import { clamp, DEG } from "./math";
import { mixHex, PAL } from "./palette";
import { createPost } from "./post";
import { createSolidMaterial } from "./solid";
import { evaluate, type Frame } from "./timeline";
import { createShared, MAX_SHIPS } from "./uniforms";
import { buildWorld, SHIPS } from "./world";

interface Tier {
  dprCap: number;
  samples: number;
  /** Reflection target scale (0 = no reflection pass). */
  refl: number;
  waves: number;
  clouds: boolean;
  detail: number;
}

const TIERS: Record<VoyageQuality, Tier> = {
  high: { dprCap: 1.75, samples: 4, refl: 0.5, waves: 6, clouds: true, detail: 1 },
  medium: { dprCap: 1.25, samples: 2, refl: 0.35, waves: 5, clouds: true, detail: 1 },
  low: { dprCap: 1, samples: 0, refl: 0, waves: 4, clouds: false, detail: 0 },
};

const NEAR = 0.5;
const FAR = 60000;

export function createEngine(opts: VoyageOptions): Voyage {
  const canvas = opts.canvas;
  const tier = TIERS[opts.quality ?? "high"];
  const reduced = !!opts.reducedMotion;

  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: false,
    alpha: false,
    depth: false,
    stencil: false,
    powerPreference: "high-performance",
    preserveDrawingBuffer: false,
  });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.NoToneMapping;
  renderer.info.autoReset = false;
  renderer.autoClear = true;

  const shared = createShared();
  const world = buildWorld(tier.detail);
  const backdrop = createBackdrop(shared, { waves: tier.waves, clouds: tier.clouds });
  const solidMat = createSolidMaterial(shared, false);
  const mirrorMat = createSolidMaterial(shared, true);
  const lineMat = createLineMaterial(shared);
  const post = createPost();

  const solid = new THREE.Mesh(world.solid, solidMat);
  solid.frustumCulled = false;
  const lines = new THREE.Mesh(world.lines, lineMat);
  lines.frustumCulled = false;
  lines.renderOrder = 10;
  const mirror = new THREE.Mesh(world.solid, mirrorMat);
  mirror.frustumCulled = false;

  const scene = new THREE.Scene();
  scene.add(backdrop.mesh, solid, lines);
  const reflScene = new THREE.Scene();
  reflScene.add(mirror);
  const postScene = new THREE.Scene();
  postScene.add(post.mesh);

  const camera = new THREE.PerspectiveCamera(50, 1, NEAR, FAR);
  camera.rotation.order = "YXZ";

  const rtOpts = {
    type: THREE.UnsignedByteType,
    format: THREE.RGBAFormat,
    minFilter: THREE.LinearFilter,
    magFilter: THREE.LinearFilter,
    generateMipmaps: false,
    depthBuffer: true,
    stencilBuffer: false,
  };
  const mainRT = new THREE.WebGLRenderTarget(1, 1, { ...rtOpts, samples: tier.samples });
  const reflRT = new THREE.WebGLRenderTarget(1, 1, rtOpts);
  const blank = new THREE.DataTexture(new Uint8Array([0, 0, 0, 0]), 1, 1, THREE.RGBAFormat);
  blank.needsUpdate = true;
  backdrop.u.tRefl.value = tier.refl > 0 ? reflRT.texture : blank;
  post.u.tScene.value = mainRT.texture;

  const clearMain = new THREE.Color(1, 0, 0);
  const clearRefl = new THREE.Color(0, 0, 0);

  let cssW = 1;
  let cssH = 1;
  let dpr = 1;
  let target = 0;
  let shown = 0;
  let time = 0;
  let raf = 0;
  let running = false;
  let lost = false;
  let disposed = false;
  let dirty = true;
  let lastNow = 0;
  let lastFrame: Frame | null = null;
  let lastInfo: VoyageInfo = { calls: 0, triangles: 0, programs: 0, textures: 0, geometries: 0 };

  const fwd = new THREE.Vector3();
  const right = new THREE.Vector3();

  function dirOf(azDeg: number, elDeg: number, out: THREE.Vector3): THREE.Vector3 {
    const az = azDeg * DEG;
    const el = elDeg * DEG;
    return out.set(Math.sin(az) * Math.cos(el), Math.sin(el), -Math.cos(az) * Math.cos(el));
  }

  /** Project a direction to device px (from bottom-left); w = 1 if in front. */
  function projectDir(d: THREE.Vector3, tanH: number, top: number, bottom: number, out: THREE.Vector4): THREE.Vector4 {
    const zv = d.dot(fwd);
    if (zv <= 1e-3) return out.set(-1e4, -1e4, 0, 0);
    const xv = d.dot(right) / zv;
    const yv = d.y / zv;
    const W = shared.uRes.value.x;
    const H = shared.uRes.value.y;
    return out.set((xv / tanH * 0.5 + 0.5) * W, ((yv - bottom) / (top - bottom)) * H, 0, 1);
  }

  const proj = new THREE.Vector4();

  function apply(f: Frame): void {
    const L = f.look;
    const aspect = cssW / cssH;
    const hd = f.heading * DEG;
    fwd.set(Math.sin(hd), 0, -Math.cos(hd));
    right.set(Math.cos(hd), 0, Math.sin(hd));
    camera.position.set(f.x, f.y, f.z);
    camera.rotation.set(0, -hd, 0);
    camera.updateMatrixWorld(true);
    const tanH = Math.tan((f.hfov * DEG) / 2);
    const tanV = tanH / aspect;
    const top = 2 * tanV * f.horizon;
    const bottom = -2 * tanV * (1 - f.horizon);
    camera.projectionMatrix.makePerspective(-tanH * NEAR, tanH * NEAR, top * NEAR, bottom * NEAR, NEAR, FAR);
    camera.projectionMatrixInverse.copy(camera.projectionMatrix).invert();

    const s = shared;
    s.uTime.value = time;
    s.uCamPos.value.copy(camera.position);
    s.uFwd.value.copy(fwd);
    s.uRight.value.copy(right);
    s.uFrustum.value.set(tanH, top, bottom, 0);
    s.uNearFar.value.set(NEAR, FAR);
    dirOf(L.keyAz, Math.max(L.keyEl, 2), s.uKeyDir.value);
    s.uLightA.value.set(L.amb, L.diff, L.skyLight, L.rim);
    s.uFog.value.set(L.fogDist, L.haze, L.fogMax, L.calm);
    s.uLights.value = L.lights;
    s.uNight.value = L.night;
    s.uHatch.value.set(2.5, 0.3, 0.7, 1);

    // ships: bounded drift along the heading, heave, pitch and roll
    const amb = reduced ? 0 : 1;
    SHIPS.forEach((d, i) => {
      if (i >= MAX_SHIPS) return;
      const h = d.heading * DEG;
      const drift = amb * d.drift * Math.sin((time * Math.PI * 2) / 480 + i * 1.7);
      s.uShipPose.value[i].set(
        d.x + Math.sin(h) * drift,
        d.z - Math.cos(h) * drift,
        h,
        -0.2 + amb * 0.22 * Math.sin(time * 0.62 + i * 2.1),
      );
      s.uShipMot.value[i].set(
        amb * 0.0035 * Math.sin(time * 0.47 + i),
        amb * 0.006 * Math.sin(time * 0.53 + i * 0.7),
        1,
        L.lights,
      );
      s.uShipWake.value[i].set(d.L, d.L / 6, d.speed, d.speed > 0 ? 1 : 0);
    });

    // sky & sea
    const u = backdrop.u;
    u.uSkyA.value.set(L.skyH, L.skyT, L.skyFade * DEG, L.skyLine);
    u.uSkyB.value.set(L.warm, L.afterglow, L.stars, L.lineLum);
    u.uSeaA.value.set(L.seaDeep, L.seaRefl, L.seaK, L.swell);
    u.uSeaB.value.set(L.glitter, L.foam, tier.refl > 0 ? L.reflAmt : 0, 2.5);
    u.uGround.value = L.ground;
    const sizeK = 0.72 + 0.28 * clamp(cssW / 1440, 0, 1);
    dirOf(L.sunAz, L.sunEl, u.uSunDir.value);
    projectDir(u.uSunDir.value, tanH, top, bottom, proj);
    u.uSunA.value.set(proj.x, proj.y, L.sunR * sizeK * dpr, proj.w * L.sunVis);
    u.uSunB.value.set(L.sunRings, L.sunGlow, L.sunBrass, 0);
    dirOf(L.moonAz, L.moonEl, u.uMoonDir.value);
    projectDir(u.uMoonDir.value, tanH, top, bottom, proj);
    u.uMoonA.value.set(proj.x, proj.y, L.moonR * sizeK * dpr, proj.w * L.moonVis);
    u.uCalm.value.set(L.calmX, L.calmY, L.calmW, L.calmH);
    u.uCloudA.value.set(L.cloud, L.cloudScale, L.cloudHeight, L.cloudStep);
    u.uCloudB.value.set(L.cloudX, L.cloudY, L.cloudW, L.cloudH);
    u.uGullAmt.value = L.gulls;
    f.gulls.forEach((g, j) => {
      const gx = g[0] + amb * 0.012 * Math.sin(time * 0.23 + j * 1.7);
      const gy = g[1] + amb * 0.008 * Math.cos(time * 0.31 + j * 2.1);
      u.uGull.value[j].set(gx, gy, g[2] * (1 - 0.2 * f.portrait), j * 0.37);
    });

    // print palette
    const p = post.u;
    const n = L.night;
    mixHex(PAL.navy, PAL.navyDeep, n, p.uDark.value);
    mixHex(PAL.paper, PAL.line, n, p.uLight.value);
    mixHex(PAL.brass, PAL.brassLight, n * 0.8, p.uBrass.value);
    mixHex(PAL.brassLight, PAL.brass, 0.3, p.uGlowCol.value).multiplyScalar(0.55);
    p.uPlate.value.set(0.94 - 0.12 * n, 0.915 - 0.07 * n, 0.87 + 0.03 * n);
    p.uPost.value.set(L.bleed, 0.24, L.vignette, 0);
    p.uEdge.value.set(L.edge, L.lineLum, 0.7, 0.95);
    p.uLights.value = L.lights;
    p.uDpr.value = dpr;
  }

  function draw(progress: number): void {
    if (lost || disposed) return;
    const f = evaluate(progress, cssW / cssH);
    apply(f);
    lastFrame = f;
    renderer.info.reset();
    if (tier.refl > 0) {
      renderer.setRenderTarget(reflRT);
      renderer.setClearColor(clearRefl, 0);
      renderer.render(reflScene, camera);
    }
    renderer.setRenderTarget(mainRT);
    renderer.setClearColor(clearMain, 1);
    renderer.render(scene, camera);
    renderer.setRenderTarget(null);
    renderer.render(postScene, camera);
    const i = renderer.info;
    lastInfo = {
      calls: i.render.calls,
      triangles: i.render.triangles,
      programs: i.programs ? i.programs.length : 0,
      textures: i.memory.textures,
      geometries: i.memory.geometries,
    };
    dirty = false;
  }

  function tick(now: number): void {
    raf = requestAnimationFrame(tick);
    const dt = lastNow ? Math.min(0.1, Math.max(0, (now - lastNow) / 1000)) : 0;
    lastNow = now;
    const before = shown;
    if (reduced) shown = target;
    else {
      time += dt;
      shown += (target - shown) * (1 - Math.exp(-dt * 6));
      if (Math.abs(target - shown) < 1e-4) shown = target;
    }
    if (reduced && !dirty && before === shown) return;
    draw(shown);
  }

  function start(): void {
    if (running || disposed) return;
    running = true;
    lastNow = 0;
    if (!lost) raf = requestAnimationFrame(tick);
  }

  function stop(): void {
    running = false;
    cancelAnimationFrame(raf);
    raf = 0;
  }

  const onLost = (e: Event): void => {
    e.preventDefault();
    lost = true;
    cancelAnimationFrame(raf);
    raf = 0;
  };
  const onRestored = (): void => {
    lost = false;
    post.paper.needsUpdate = true;
    blank.needsUpdate = true;
    dirty = true;
    if (running) {
      lastNow = 0;
      raf = requestAnimationFrame(tick);
    } else draw(shown);
  };
  canvas.addEventListener("webglcontextlost", onLost, false);
  canvas.addEventListener("webglcontextrestored", onRestored, false);

  return {
    setProgress(p: number) {
      target = clamp(Number.isFinite(p) ? p : 0, 0, 1);
      dirty = true;
    },
    setSize(w: number, h: number, ratio: number) {
      cssW = Math.max(1, w);
      cssH = Math.max(1, h);
      dpr = clamp(ratio || 1, 0.5, tier.dprCap);
      renderer.setPixelRatio(dpr);
      renderer.setSize(cssW, cssH, false);
      const size = renderer.getDrawingBufferSize(new THREE.Vector2());
      shared.uRes.value.copy(size);
      shared.uDpr.value = dpr;
      post.u.uRes.value.copy(size);
      mainRT.setSize(size.x, size.y);
      if (tier.refl > 0) reflRT.setSize(Math.max(1, Math.round(size.x * tier.refl)), Math.max(1, Math.round(size.y * tier.refl)));
      dirty = true;
    },
    setTime(seconds: number) {
      time = seconds;
      dirty = true;
    },
    start,
    stop,
    renderOnce() {
      shown = target;
      draw(shown);
    },
    getHorizonY() {
      const f = lastFrame ?? evaluate(target, cssW / cssH);
      const y = f.horizon * cssH;
      return y >= 0 && y <= cssH ? y : null;
    },
    info() {
      return { ...lastInfo };
    },
    dispose() {
      if (disposed) return;
      stop();
      disposed = true;
      canvas.removeEventListener("webglcontextlost", onLost, false);
      canvas.removeEventListener("webglcontextrestored", onRestored, false);
      world.solid.dispose();
      world.lines.dispose();
      backdrop.mesh.geometry.dispose();
      post.mesh.geometry.dispose();
      for (const m of [backdrop.material, solidMat, mirrorMat, lineMat, post.material]) m.dispose();
      post.paper.dispose();
      blank.dispose();
      mainRT.dispose();
      reflRT.dispose();
      renderer.dispose();
    },
  };
}
