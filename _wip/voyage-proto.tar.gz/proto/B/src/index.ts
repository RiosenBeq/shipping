import type { CreateVoyage } from "../../contract";
import { createEngine } from "./engine";

export { SCENES as VOYAGE_SCENES } from "../../contract";

/** LEVANTER voyage, take B: "Engraved chart" — a living maritime engraving. */
export const createVoyage: CreateVoyage = (opts) => createEngine(opts);
