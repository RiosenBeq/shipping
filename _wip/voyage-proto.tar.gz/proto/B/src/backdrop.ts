import * as THREE from "three";
import { GLSL_COMMON } from "./glsl";
import type { Shared } from "./uniforms";

/**
 * The plate's ground: sky and an analytic, infinite sea, drawn as one
 * full-screen triangle. Each pixel's view ray is rebuilt from the lens-shifted
 * frustum, so the sea meets the true horizon exactly where getHorizonY() says;
 * the sea writes gl_FragDepth so land and hulls sit in it correctly.
 *
 * Sky: ruled lines (fixed CSS spacing, anchored to the horizon) whose weight
 * fades upward and breaks into dashes; contour-hatched clouds; brass sun with
 * fine rings; moon, stars, gulls.
 * Sea: horizontal rules spaced by log-depth (tightening toward the horizon,
 * octave-folded below ~2.5 px) displaced by the swell; weight from a fake
 * Fresnel/sky reflection; glitter breaks rules into dashes; foam as stipple;
 * reflections of the solid scene from a low-res mirrored pass.
 */
export interface BackdropOptions {
  waves: number;
  clouds: boolean;
}

const VERT = /* glsl */ `
void main() { gl_Position = vec4(position.xy, 0.0, 1.0); }
`;

const FRAG = (o: BackdropOptions) => /* glsl */ `
#define NWAVES ${o.waves}
${o.clouds ? "#define CLOUDS" : ""}
uniform vec2 uRes;
uniform float uDpr;
uniform float uTime;
uniform vec3 uCamPos;
uniform vec3 uFwd;
uniform vec3 uRight;
uniform vec4 uFrustum;
uniform vec2 uNearFar;
uniform vec4 uFog;
uniform float uLights;
uniform float uNight;
uniform vec4 uShipPose[8];
uniform vec4 uShipWake[8];
uniform vec4 uSkyA;
uniform vec4 uSkyB;
uniform vec4 uSeaA;
uniform vec4 uSeaB;
uniform vec4 uSunA;
uniform vec4 uSunB;
uniform vec3 uSunDir;
uniform vec4 uMoonA;
uniform vec3 uMoonDir;
uniform vec4 uCalm;
uniform vec4 uCloudA;
uniform vec4 uCloudB;
uniform vec4 uGull[6];
uniform float uGullAmt;
uniform float uGround;
uniform sampler2D tRefl;
${GLSL_COMMON}

const vec4 WAVES[6] = vec4[6](
  vec4(0.0, 1.0, 61.0, 0.50),
  vec4(0.34, 0.94, 35.0, 0.33),
  vec4(-0.45, 0.89, 21.5, 0.22),
  vec4(0.81, 0.59, 13.0, 0.11),
  vec4(-0.66, 0.75, 7.9, 0.06),
  vec4(0.21, -0.98, 4.9, 0.035)
);

vec3 waves(vec2 p, float fp) {
  vec3 acc = vec3(0.0);
  for (int i = 0; i < NWAVES; i++) {
    vec4 w = WAVES[i];
    float k = 6.2831853 / w.z;
    float om = sqrt(9.81 * k);
    float a = w.w * uSeaA.w * (1.0 - smoothstep(w.z * 0.1, w.z * 0.35, fp));
    float ph = k * dot(w.xy, p) - om * uTime + float(i) * 1.93;
    // slightly peaked crests (trochoid-like): sharper tops, flatter troughs
    float s = sin(ph);
    float c = cos(ph);
    acc.x += a * (s + 0.18 * (1.0 - c * c));
    acc.yz += a * k * c * (1.0 + 0.36 * s) * w.xy;
  }
  return acc;
}

float wakeFoam(vec2 p) {
  float f = 0.0;
  for (int i = 0; i < 8; i++) {
    vec4 wk = uShipWake[i];
    if (wk.w <= 0.0) continue;
    vec4 ps = uShipPose[i];
    vec2 fw = vec2(sin(ps.z), -cos(ps.z));
    vec2 rt = vec2(cos(ps.z), sin(ps.z));
    vec2 d = p - ps.xy;
    float u = dot(d, fw);
    float w = dot(d, rt);
    float L = wk.x;
    float B = wk.y;
    float behind = -u - 0.5 * L;
    if (behind > 18.0 * L || abs(w) > 5.0 * L || u > L) continue;
    float bh = max(behind, 0.0);
    float spread = 0.55 * B * (1.0 + 0.03 * bh);
    float turb = exp(-(w * w) / (spread * spread)) * smoothstep(-0.03 * L, 0.04 * L, behind) * exp(-bh / (2.6 * L * wk.z + 1.0));
    float armX = 0.36 * max(behind + 0.4 * L, 0.0);
    float arm = exp(-abs(abs(w) - armX) / (1.0 + 0.03 * bh)) * step(-0.4 * L, behind) * exp(-bh / (2.2 * L)) * 0.6;
    float side = exp(-pow((abs(w) - 0.5 * B) / (0.16 * B + 0.6), 2.0)) * step(abs(u), 0.5 * L) * (0.2 + 0.8 * smoothstep(0.0, 0.48 * L, u));
    float bow = exp(-pow((u - 0.48 * L) / (0.04 * L + 2.0), 2.0)) * exp(-pow(w / (0.75 * B), 2.0));
    f = max(f, (turb * 0.85 + arm + side * 0.7 + bow) * wk.z * wk.w);
  }
  return f;
}

vec4 sky(vec2 frag, float xv, float yv, float hzPx, vec2 uvTop, float calm) {
  vec3 dir = normalize(uFwd + uRight * xv + vec3(0.0, yv, 0.0));
  float elev = asin(clamp(dir.y, 0.0, 1.0));
  float t = mix(uSkyA.x, uSkyA.y, smoothstep(0.0, uSkyA.z, elev));
  float lineLum = uSkyB.w;

  // sun: the plate is wiped clean in a halo around it
  float dSun = length(frag - uSunA.xy);
  float rS = max(uSunA.z, 1.0);
  float halo = exp(-max(dSun - rS, 0.0) / (rS * 3.2)) * uSunA.w;
  t = mix(t, 1.0, halo * uSunB.y);
  // moon: a softly lit patch of sky
  float dMoon = length(frag - uMoonA.xy);
  float rM = max(uMoonA.z, 1.0);
  float mhalo = exp(-max(dMoon - rM, 0.0) / (rM * 3.0)) * uMoonA.w;
  t = max(t, mix(t, 0.5, mhalo * 0.55));

  // warm haze / afterglow tint on the rules near the horizon
  float lowSky = 1.0 - smoothstep(0.0, uSkyA.z * 0.75, elev);
  vec2 sunH = normalize(uSunDir.xz + vec2(1e-5));
  float sunSide = 0.5 + 0.5 * dot(normalize(dir.xz + vec2(1e-5)), sunH);
  float warm = clamp(uSkyB.x * lowSky * (0.35 + 0.65 * halo) + uSkyB.y * lowSky * mix(0.35, 1.15, sunSide), 0.0, 1.0);
  // afterglow also lifts the tone low over the sunset side
  t = mix(t, max(t, uSkyA.x + 0.12), uSkyB.y * lowSky * sunSide * 0.6);

  // ---- clouds: contour-hatched shapes ----
  float con = 0.0;
  float cloud = 0.0;
#ifdef CLOUDS
  {
    vec2 pc = uCamPos.xz + (uFwd.xz + uRight.xz * xv) * (uCloudA.z / max(yv, 0.002));
    vec2 q = pc * uCloudA.y + vec2(uTime * 0.004, uTime * 0.0015);
    float n = fbm3(q);
    vec2 rq = (uvTop - uCloudB.xy) / uCloudB.zw;
    float reg = 1.0 - smoothstep(0.25, 1.0, length(rq));
    float hzf = smoothstep(0.01, 0.07, elev);
    float mask = reg * hzf * (1.0 - calm) * uCloudA.x;
    // the field varies everywhere; clouds are where it rises above zero
    float field = n - 0.62 + 0.14 * reg;
    float vc = field / uCloudA.w;
    float fwc = max(length(vec2(dFdx(vc), dFdy(vc))), 1e-4);
    float distC = abs(fract(vc + 0.5) - 0.5) / fwc;
    float wpx = mix(0.55, 0.3, clamp(vc / 4.0, 0.0, 1.0)) * uDpr;
    float present = smoothstep(0.05, 0.35, mask);
    con = lineBox(distC, wpx) * step(-0.5, vc) * (1.0 - smoothstep(2.5, 3.5, vc)) * (1.0 - smoothstep(0.22, 0.45, fwc)) * present;
    cloud = smoothstep(-0.25, 0.5, vc) * present;
    // underside in shade: density rising upward → we are at the bottom edge
    float under = clamp(dFdy(vc) / fwc, -1.0, 1.0);
    float tc = mix(1.0, 0.66, smoothstep(-0.2, 0.9, under) * (1.0 - smoothstep(0.4, 2.0, vc)));
    t = mix(t, mix(tc, t * 0.85, uNight), cloud);
  }
#endif

  // ---- sky rules: very fine, fading upward, breaking into dashes ----
  float sp = uSkyA.w * uDpr;
  float v = (frag.y - hzPx) / sp;
  float u = frag.x / (sp * 7.0);
  t = mix(t, uGround, calm);
  float d = 1.0 - t;
  float ink = ruleInkB(v, u, d, 1.0 / sp, 1.0 / (sp * 7.0), 0.22);
  float lum = 1.0 - ink;
  float dayness = smoothstep(0.35, 0.65, t);
  float brass = warm * mix(lum, ink, dayness) * 0.85;
  lum = mix(lum, lineLum, con * 0.85);

  // ---- stars ----
  if (uSkyB.z > 0.0) {
    float az = atan(dir.x, -dir.z);
    vec2 g = vec2(az, elev) * (57.29578 / 0.8);
    vec2 cell = floor(g);
    vec2 f = g - cell;
    float h = hash12(cell + 0.37);
    float dens = uSkyB.z * 0.2 * smoothstep(0.03, 0.22, elev) * (1.0 - 0.8 * calm) * (1.0 - cloud);
    if (h < dens) {
      vec2 spos = 0.15 + 0.7 * hash22(cell + 5.1);
      float pxCell = 0.8 * 0.0174533 * uRes.y / (uFrustum.y - uFrustum.z);
      vec2 dd = (f - spos) * pxCell * vec2(cos(elev), 1.0);
      float mag = hash12(cell + 9.7);
      float rad = (0.3 + 0.85 * mag * mag) * uDpr;
      float tw = 0.72 + 0.28 * sin(uTime * (0.7 + 2.3 * mag) + h * 91.0);
      float star = clamp(rad - length(dd) + 0.5, 0.0, 1.0);
      if (mag > 0.86) {
        float arm = 3.6 * uDpr * mag;
        star = max(star, 0.75 * lineBox(abs(dd.x), 0.3 * uDpr) * (1.0 - smoothstep(0.0, arm, abs(dd.y))));
        star = max(star, 0.75 * lineBox(abs(dd.y), 0.3 * uDpr) * (1.0 - smoothstep(0.0, arm, abs(dd.x))));
      }
      lum = mix(lum, 1.0, star * tw);
    }
  }

  // ---- moon: sand disc, engraved maria, faint halo rings ----
  float glow = 0.0;
  if (uMoonA.w > 0.0) {
    float md = clamp(rM - dMoon + 0.5, 0.0, 1.0);
    vec2 mp = (frag - uMoonA.xy) / rM;
    float maria = smoothstep(0.5, 0.72, vnoise(mp * 2.2 + 3.7)) * 0.3 + smoothstep(0.6, 0.8, vnoise(mp * 4.1 + 1.3)) * 0.15;
    float mv = (frag.y - uMoonA.y) / (1.6 * uDpr);
    float mhatch = ruleInk(mv, maria * 1.4, 1.0 / (1.6 * uDpr));
    float rsp = max(rM * 0.5, 4.0 * uDpr);
    float rr = (dMoon - rM * 1.45) / rsp;
    float rd = abs(fract(rr + 0.5) - 0.5) * rsp;
    float ring = lineBox(rd, 0.3 * uDpr) * step(-0.5, rr) * (1.0 - smoothstep(1.5, 4.0, rr)) * 0.55;
    lum = mix(lum, 1.0 - mhatch, md * uMoonA.w);
    lum = mix(lum, 1.0, ring * uMoonA.w);
    brass = max(brass, ring * uMoonA.w * 0.35);
    glow = md * uMoonA.w * 0.22 + mhalo * 0.05;
  }

  // ---- sun: brass disc crossed by haze bands, fine concentric rings ----
  if (uSunA.w > 0.0) {
    float sd = clamp(rS - dSun + 0.5, 0.0, 1.0);
    float bsp = uSkyA.w * uDpr * 1.1;
    float bv = (frag.y - uSunA.y) / bsp;
    float bd = smoothstep(0.3, -1.0, (frag.y - uSunA.y) / rS) * 0.5;
    float bands = ruleInk(bv, bd, 1.0 / bsp);
    float ringSp = max(rS * 0.34, 4.5 * uDpr);
    float rr = (dSun - rS * 1.32) / ringSp;
    float rd = abs(fract(rr + 0.5) - 0.5) * ringSp;
    float ring = lineBox(rd, mix(0.5, 0.28, clamp(rr / 7.0, 0.0, 1.0)) * uDpr) * step(-0.5, rr) * (1.0 - smoothstep(2.5, 7.5, rr)) * uSunB.x;
    float disc = sd * (1.0 - bands);
    lum = mix(lum, 1.0, sd * uSunA.w);
    brass = max(brass, max(disc, ring) * uSunA.w);
  }

  // ---- gulls: engraved strokes, wings flapping ----
  if (uGullAmt > 0.0) {
    float gl = 0.0;
    for (int i = 0; i < 6; i++) {
      vec4 gp = uGull[i];
      if (gp.z <= 0.0) continue;
      vec2 c = vec2(gp.x * uRes.x, (1.0 - gp.y) * uRes.y);
      float s = gp.z * uDpr;
      vec2 p = (frag - c) / s;
      if (abs(p.x) > 1.2 || abs(p.y) > 1.0) continue;
      float flap = sin(uTime * 6.5 + gp.w * 6.2832);
      float ax = abs(p.x);
      float lift = 0.3 + 0.2 * flap;
      float fy = lift * sin(ax * 3.0) - (0.18 + 0.12 * flap) * ax * ax;
      float fd = lift * 3.0 * cos(ax * 3.0) - 2.0 * (0.18 + 0.12 * flap) * ax;
      float dist = abs(p.y - fy) * s / sqrt(1.0 + fd * fd);
      float wdt = mix(1.1, 0.35, ax) * uDpr;
      gl = max(gl, lineBox(dist, 0.5 * wdt) * step(ax, 1.0));
    }
    lum = mix(lum, lineLum, gl * uGullAmt);
  }
  return vec4(lum, clamp(brass, 0.0, 1.0), glow, 1.0);
}

vec4 sea(vec2 frag, float xv, float yv, float calm, out float depthOut) {
  float camH = uCamPos.y;
  float depth = min(camH / -yv, 3.0e5);
  depthOut = depth;
  vec3 hdir = uFwd + uRight * xv;
  vec2 wxz = uCamPos.xz + hdir.xz * depth;
  float pxW = depth * (uFrustum.y - uFrustum.z) / uRes.y;
  float pxD = pxW * depth / camH;
  vec3 w = waves(wxz, max(pxW, 0.3 * pxD));

  // rules: log-depth spacing, displaced by the swell
  float v = uSeaA.z * (log(depth) + w.x / camH);

  // tone: water body vs reflected sky (stylised Fresnel)
  vec3 n = normalize(vec3(-w.y, 1.0, -w.z));
  vec3 rd = normalize(vec3(hdir.x, yv, hdir.z));
  float ndv = clamp(dot(n, -rd), 0.0, 1.0);
  float fres = pow(1.0 - ndv, 4.0);
  vec3 R = reflect(rd, n);
  float rEl = asin(clamp(R.y, 0.0, 1.0));
  float skyT = mix(uSkyA.x, uSkyA.y, smoothstep(0.0, uSkyA.z, rEl));
  float t = mix(uSeaA.x, skyT, clamp(0.06 + fres * uSeaA.y, 0.0, 0.9));
  float F = (1.0 - exp(-depth / (uFog.x * 1.5))) * uFog.z;
  t = mix(t, uSkyA.x * 0.94, F * 0.8);

  // reflections of the solid scene, rippled; lights stretch into streaks
  float latS = dot(w.yz, uRight.xz);
  float depS = dot(w.yz, uFwd.xz);
  vec2 ruv = (frag + vec2(latS, depS * 0.5) * (120.0 * uDpr)) / uRes;
  vec4 rf = texture2D(tRefl, ruv);
  float ext = (5.0 + 10.0 * abs(depS)) * uDpr / uRes.y;
  float gR = max(rf.g, max(texture2D(tRefl, ruv + vec2(0.0, ext)).g, texture2D(tRefl, ruv - vec2(0.0, ext * 1.6)).g));
  float rA = rf.a * uSeaB.z * mix(0.5, 1.0, fres);
  t = mix(t, rf.r, rA);

  // glitter (sun / moon / lights): rules break into dashes
  float sunDot = max(dot(R, uSunDir), 0.0);
  float moonDot = max(dot(R, uMoonDir), 0.0);
  float spark = vnoise(vec2(frag.x / (15.0 * uDpr) + uTime * 0.45 + 7.0 * hash11(floor(v)), v * 0.93 - uTime * 0.2));
  float g = (pow(sunDot, 90.0) * uSunA.w + pow(moonDot, 110.0) * uMoonA.w * 1.3) * uSeaB.x;
  g = max(g, gR * uLights * 1.4);
  g = clamp(g, 0.0, 1.0);
  float glit = smoothstep(1.0 - g, 1.18 - g, spark);
  t = mix(t, 0.97, glit);

  // calm area behind the copy: rules relax toward the plain ground
  t = mix(t, uGround, calm * 0.45);

  float dInk = clamp(1.0 - t, 0.0, 1.0);
  float ink = ruleInkLOD(v, dInk, uSeaB.w * uDpr);
  float lum = 1.0 - ink;

  // foam: wakes and wind-blown crests, stippled
  float foam = wakeFoam(wxz);
  float crest = smoothstep(0.55, 0.95, w.x / max(uSeaA.w, 0.01)) * (1.0 - smoothstep(150.0, 700.0, depth));
  foam = max(foam, crest * uSeaB.y * (0.3 + 0.7 * vnoise(wxz * 0.25)));
  foam *= (0.55 + 0.45 * vnoise(wxz * 0.6 + uTime * 0.2)) * (1.0 - smoothstep(0.6, 3.0, pxW));
  float tf = mix(t, mix(0.9, 0.45, uNight), 0.85);
  float st = stippleLum(frag, tf, 2.3 * uDpr);
  lum = mix(lum, st, smoothstep(0.08, 0.5, foam));

  float core = smoothstep(0.35, 0.85, g);
  float brass = glit * core * mix(uSunB.z * uSunA.w, 0.75, max(uLights * gR, uMoonA.w * 0.4));
  float glow = glit * gR * uLights * 0.6;
  return vec4(lum, clamp(brass, 0.0, 1.0), glow, 1.0);
}

void main() {
  vec2 frag = gl_FragCoord.xy;
  float fy = frag.y / uRes.y;
  float xv = (frag.x / uRes.x * 2.0 - 1.0) * uFrustum.x;
  float yv = mix(uFrustum.z, uFrustum.y, fy);
  float hzPx = uRes.y * (-uFrustum.z) / (uFrustum.y - uFrustum.z);
  vec2 uvTop = vec2(frag.x / uRes.x, 1.0 - fy);
  float calm = uFog.w * (1.0 - smoothstep(0.45, 1.0, length((uvTop - uCalm.xy) / uCalm.zw)));
  // branch per 2x2 quad so derivatives stay defined
  float qy = floor(frag.y * 0.5) * 2.0 + 1.0 - hzPx;
  vec4 skyC = vec4(1.0, 0.0, 0.0, 1.0);
  vec4 seaC = vec4(1.0, 0.0, 0.0, 1.0);
  float seaDepth = 3.0e5;
  if (qy > -3.0) skyC = sky(frag, xv, max(yv, 1e-5), hzPx, uvTop, calm);
  if (qy < 3.0) seaC = sea(frag, xv, min(yv, -1e-7), calm, seaDepth);
  float wSky = clamp(frag.y - hzPx + 0.5, 0.0, 1.0);
  gl_FragColor = mix(seaC, skyC, wSky);
  float n = uNearFar.x;
  float f = uNearFar.y;
  float ndcZ = (f + n) / (f - n) - 2.0 * f * n / ((f - n) * max(seaDepth, n));
  gl_FragDepth = wSky > 0.5 ? 0.9999999 : clamp(ndcZ * 0.5 + 0.5, 0.0, 0.9999998);
}
`;

export interface Backdrop {
  mesh: THREE.Mesh;
  material: THREE.ShaderMaterial;
  u: ReturnType<typeof backdropUniforms>;
}

function backdropUniforms() {
  return {
    uSkyA: { value: new THREE.Vector4(0.8, 1, 0.15, 3.4) },
    uSkyB: { value: new THREE.Vector4(0, 0, 0, 0) },
    uSeaA: { value: new THREE.Vector4(0.4, 1, 40, 0.6) },
    uSeaB: { value: new THREE.Vector4(1, 0.3, 0.6, 2.6) },
    uSunA: { value: new THREE.Vector4(0, 0, 20, 0) },
    uSunB: { value: new THREE.Vector4(1, 0.6, 0.5, 0) },
    uSunDir: { value: new THREE.Vector3(0, 0.1, -1).normalize() },
    uMoonA: { value: new THREE.Vector4(0, 0, 14, 0) },
    uMoonDir: { value: new THREE.Vector3(0, 0.2, 1).normalize() },
    uCalm: { value: new THREE.Vector4(0.3, 0.4, 0.3, 0.3) },
    uCloudA: { value: new THREE.Vector4(0, 0.0004, 1600, 0.12) },
    uCloudB: { value: new THREE.Vector4(0.75, 0.3, 0.3, 0.2) },
    uGull: { value: Array.from({ length: 6 }, () => new THREE.Vector4()) },
    uGullAmt: { value: 0 },
    uGround: { value: 1 },
    tRefl: { value: null as THREE.Texture | null },
  };
}

export function createBackdrop(shared: Shared, o: BackdropOptions): Backdrop {
  const u = backdropUniforms();
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute([-1, -1, 0, 3, -1, 0, -1, 3, 0], 3));
  const material = new THREE.ShaderMaterial({
    uniforms: { ...shared, ...u },
    vertexShader: VERT,
    fragmentShader: FRAG(o),
    depthTest: true,
    depthWrite: true,
  });
  const mesh = new THREE.Mesh(g, material);
  mesh.frustumCulled = false;
  mesh.renderOrder = -100;
  return { mesh, material, u };
}
