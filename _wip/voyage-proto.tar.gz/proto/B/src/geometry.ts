import * as THREE from "three";
import type { V3 } from "./math";

/** Surface hatch style, read by the solid shader (aMat.w). */
export const STYLE = {
  /** world-height rules (domes get latitude lines, walls get courses). */
  PLAIN: 0,
  /** horizontal surfaces: rules run along the ship (local z = const). */
  DECK: 1,
  /** hull sides: lighter boot-top band near the waterline. */
  HULL: 2,
  /** land curtains: two-sided, terrain/urban texture, windows at night. */
  CURTAIN: 3,
} as const;

export interface MatSpec {
  /** Albedo tone, 0 = ink-dark paint .. 1 = white paint. */
  tone: number;
  /** Brass coverage (funnel bands, cargo pipes). */
  brass?: number;
  /** Emissive amount at night (windows, lanterns). */
  glow?: number;
  style?: number;
}

/** Placement: translation + yaw (radians, about +y) + optional uniform scale. */
export interface Place {
  x: number;
  y: number;
  z: number;
  yaw?: number;
  s?: number;
}

/**
 * Accumulates an indexed mesh with the engraving attributes:
 *   aMat = (tone, brass, glow, style), aExt = (ship index or -1, urban, seed, arc length).
 */
export class MeshBuilder {
  private pos: number[] = [];
  private nor: number[] = [];
  private mat: number[] = [];
  private ext: number[] = [];
  private idx: number[] = [];
  ship = -1;
  urban = 0;
  seed = 0;
  place: Place = { x: 0, y: 0, z: 0 };

  get vertexCount(): number {
    return this.pos.length / 3;
  }

  private xf(p: V3): V3 {
    const pl = this.place;
    const s = pl.s ?? 1;
    const yaw = pl.yaw ?? 0;
    const c = Math.cos(yaw);
    const sn = Math.sin(yaw);
    const x = p[0] * s;
    const z = p[2] * s;
    return [pl.x + x * c + z * sn, pl.y + p[1] * s, pl.z - x * sn + z * c];
  }

  private xn(n: V3): V3 {
    const yaw = this.place.yaw ?? 0;
    const c = Math.cos(yaw);
    const sn = Math.sin(yaw);
    return [n[0] * c + n[2] * sn, n[1], -n[0] * sn + n[2] * c];
  }

  vertex(p: V3, n: V3, m: MatSpec, s = 0): number {
    const wp = this.xf(p);
    const wn = this.xn(n);
    this.pos.push(wp[0], wp[1], wp[2]);
    this.nor.push(wn[0], wn[1], wn[2]);
    this.mat.push(m.tone, m.brass ?? 0, m.glow ?? 0, m.style ?? 0);
    this.ext.push(this.ship, this.urban, this.seed, s);
    return this.vertexCount - 1;
  }

  tri(a: number, b: number, c: number): void {
    this.idx.push(a, b, c);
  }

  quad(a: number, b: number, c: number, d: number): void {
    this.idx.push(a, b, c, a, c, d);
  }

  /** Flat quad from four local points (counter-clockwise seen from outside). */
  face(a: V3, b: V3, c: V3, d: V3, m: MatSpec): void {
    const ux = b[0] - a[0];
    const uy = b[1] - a[1];
    const uz = b[2] - a[2];
    const vx = d[0] - a[0];
    const vy = d[1] - a[1];
    const vz = d[2] - a[2];
    let nx = uy * vz - uz * vy;
    let ny = uz * vx - ux * vz;
    let nz = ux * vy - uy * vx;
    const l = Math.hypot(nx, ny, nz) || 1;
    nx /= l;
    ny /= l;
    nz /= l;
    const n: V3 = [nx, ny, nz];
    const i0 = this.vertex(a, n, m);
    const i1 = this.vertex(b, n, m);
    const i2 = this.vertex(c, n, m);
    const i3 = this.vertex(d, n, m);
    this.quad(i0, i1, i2, i3);
  }

  /**
   * Box standing on (cx, cy, cz) with size (sx, sy, sz), local yaw, optional top
   * taper (top scale). Bottom face omitted (never seen above the water).
   */
  box(cx: number, cy: number, cz: number, sx: number, sy: number, sz: number, m: MatSpec, taper = 1, yaw = 0): void {
    const hx = sx / 2;
    const hz = sz / 2;
    const tx = hx * taper;
    const tz = hz * taper;
    const c = Math.cos(yaw);
    const s = Math.sin(yaw);
    const P = (x: number, y: number, z: number): V3 => [cx + x * c + z * s, cy + y, cz - x * s + z * c];
    const b0 = P(-hx, 0, -hz);
    const b1 = P(hx, 0, -hz);
    const b2 = P(hx, 0, hz);
    const b3 = P(-hx, 0, hz);
    const t0 = P(-tx, sy, -tz);
    const t1 = P(tx, sy, -tz);
    const t2 = P(tx, sy, tz);
    const t3 = P(-tx, sy, tz);
    this.face(b3, b2, t2, t3, m); // +z
    this.face(b1, b0, t0, t1, m); // -z
    this.face(b2, b1, t1, t2, m); // +x
    this.face(b0, b3, t3, t0, m); // -x
    this.face(t3, t2, t1, t0, { ...m, style: m.style === STYLE.HULL ? STYLE.PLAIN : m.style }); // top
  }

  /**
   * Surface of revolution about the local y axis through (cx, cy, cz):
   * profile = list of [radius, height] from bottom to top. Smooth normals.
   */
  lathe(cx: number, cy: number, cz: number, profile: [number, number][], seg: number, m: MatSpec): void {
    const base = this.vertexCount;
    const rows = profile.length;
    for (let j = 0; j < rows; j++) {
      const [r, h] = profile[j];
      const prev = profile[Math.max(0, j - 1)];
      const next = profile[Math.min(rows - 1, j + 1)];
      // profile tangent (dr, dh) → outward normal (dh, -dr)
      let nr = next[1] - prev[1];
      let nh = -(next[0] - prev[0]);
      const l = Math.hypot(nr, nh) || 1;
      nr /= l;
      nh /= l;
      for (let i = 0; i <= seg; i++) {
        const a = (i / seg) * Math.PI * 2;
        const ca = Math.cos(a);
        const sa = Math.sin(a);
        this.vertex([cx + r * ca, cy + h, cz + r * sa], [nr * ca, nh, nr * sa], m);
      }
    }
    for (let j = 0; j < rows - 1; j++) {
      for (let i = 0; i < seg; i++) {
        const a = base + j * (seg + 1) + i;
        const b = a + seg + 1;
        this.quad(a, b, b + 1, a + 1);
      }
    }
  }

  /** Hemisphere (optionally stretched vertically: k > 1 makes an ogee-ish cap). */
  dome(cx: number, cy: number, cz: number, r: number, m: MatSpec, seg = 14, rings = 6, k = 1): void {
    const prof: [number, number][] = [];
    for (let j = 0; j <= rings; j++) {
      const a = (j / rings) * (Math.PI / 2);
      prof.push([Math.max(r * Math.cos(a), 0.001), r * k * Math.sin(a)]);
    }
    this.lathe(cx, cy, cz, prof, seg, m);
  }

  /** Cylinder / cone frustum along local y. */
  cyl(cx: number, cy: number, cz: number, r0: number, r1: number, h: number, m: MatSpec, seg = 12, cap = true): void {
    this.lathe(cx, cy, cz, [[r0, 0], [r1, h]], seg, m);
    if (cap && r1 > 0.01) {
      const c = this.vertex([cx, cy + h, cz], [0, 1, 0], m);
      const ring: number[] = [];
      for (let i = 0; i <= seg; i++) {
        const a = (i / seg) * Math.PI * 2;
        ring.push(this.vertex([cx + r1 * Math.cos(a), cy + h, cz + r1 * Math.sin(a)], [0, 1, 0], m));
      }
      for (let i = 0; i < seg; i++) this.tri(c, ring[i + 1], ring[i]);
    }
  }

  /** Horizontal capsule along local x (pressurised cargo tank). */
  tank(cx: number, cy: number, cz: number, len: number, r: number, m: MatSpec, seg = 14): void {
    const half = len / 2 - r;
    const prof: [number, number][] = [];
    const caps = 4;
    for (let j = 0; j <= caps; j++) {
      const a = Math.PI / 2 - (j / caps) * (Math.PI / 2);
      prof.push([r * Math.cos(a), -half - r * Math.sin(a)]);
    }
    for (let j = 0; j <= caps; j++) {
      const a = (j / caps) * (Math.PI / 2);
      prof.push([r * Math.cos(a), half + r * Math.sin(a)]);
    }
    // build along y, then rotate y → x by swapping in a temporary builder pass
    const base = this.vertexCount;
    const rows = prof.length;
    for (let j = 0; j < rows; j++) {
      const [pr, ph] = prof[j];
      const prev = prof[Math.max(0, j - 1)];
      const next = prof[Math.min(rows - 1, j + 1)];
      let nr = next[1] - prev[1];
      let nh = -(next[0] - prev[0]);
      const l = Math.hypot(nr, nh) || 1;
      nr /= l;
      nh /= l;
      for (let i = 0; i <= seg; i++) {
        const a = (i / seg) * Math.PI * 2;
        const ca = Math.cos(a);
        const sa = Math.sin(a);
        // axis = x: (h, r cos, r sin)
        this.vertex([cx + ph, cy + pr * ca, cz + pr * sa], [nh, nr * ca, nr * sa], m);
      }
    }
    for (let j = 0; j < rows - 1; j++) {
      for (let i = 0; i < seg; i++) {
        const a = base + j * (seg + 1) + i;
        const b = a + seg + 1;
        this.quad(a, a + 1, b + 1, b);
      }
    }
  }

  build(): THREE.BufferGeometry {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(this.pos, 3));
    g.setAttribute("normal", new THREE.Float32BufferAttribute(this.nor, 3));
    g.setAttribute("aMat", new THREE.Float32BufferAttribute(this.mat, 4));
    g.setAttribute("aExt", new THREE.Float32BufferAttribute(this.ext, 4));
    const n = this.pos.length / 3;
    g.setIndex(n > 65535 ? new THREE.Uint32BufferAttribute(this.idx, 1) : new THREE.Uint16BufferAttribute(this.idx, 1));
    return g;
  }
}
