import * as THREE from "three";
import { LineBuilder, LINE, GLSL_SHIP } from "../src/lines";
import { createShared } from "../src/uniforms";
declare const VERT_SRC: string;
export function run(canvas: HTMLCanvasElement, variant: string): string {
  const r = new THREE.WebGLRenderer({ canvas, antialias: false });
  r.setSize(400, 300, false);
  const shared = createShared();
  shared.uRes.value.set(400, 300);
  const L = new LineBuilder();
  L.seg([-50, 0, -100], [50, 20, -100], { kind: LINE.DARK, px: 6 });
  let vs = (window as unknown as { VS: string }).VS.replace("${GLSL_SHIP}", GLSL_SHIP);
  if (variant === "plain") vs = vs.replace("gl_Position = c;", "gl_Position = pv * vec4(position + vec3(0.0, aCorner.y * 3.0, 0.0), 1.0);");
  if (variant === "nocull") vs = vs.replace("if (ca.w < uNearFar.x || cb.w < uNearFar.x) {", "if (false) {");
  const m = new THREE.ShaderMaterial({ uniforms: { ...shared }, vertexShader: vs, fragmentShader: "void main(){ gl_FragColor = vec4(0.0,0.0,0.0,1.0); }", side: THREE.DoubleSide });
  const mesh = new THREE.Mesh(L.build(), m);
  mesh.frustumCulled = false;
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(1, 1, 1);
  scene.add(mesh);
  const cam = new THREE.PerspectiveCamera(60, 4 / 3, 0.5, 1000);
  shared.uCamPos.value.copy(cam.position);
  r.render(scene, cam);
  const gl = r.getContext();
  const px = new Uint8Array(4);
  gl.readPixels(200, 160, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, px);
  return variant + " " + JSON.stringify(Array.from(px));
}
