// Quick iteration shots for take B (same harness page, port 4102).
// usage: node B/tools/snap.cjs <name:p:vp:overlay[:t]> ...   vp = desk | mob
const { chromium } = require("/opt/node-tools/node_modules/playwright");
const path = require("path");
const fs = require("fs");
const { serve } = require("../../harness/serve.cjs");
const OUT = path.resolve(__dirname, "..", "snaps");
fs.mkdirSync(OUT, { recursive: true });
const VP = { desk: { width: 1440, height: 900 }, mob: { width: 390, height: 844 } };
(async () => {
  const server = await serve(4102);
  const browser = await chromium.launch({ args: ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"] });
  const errors = [];
  for (const spec of process.argv.slice(2)) {
    const [name, p, vp, overlay, t, dprArg] = spec.split(":");
    const ctx = await browser.newContext({ viewport: VP[vp], deviceScaleFactor: 1 });
    const page = await ctx.newPage();
    page.on("console", (m) => { if (m.type() === "error" || m.type() === "warning") errors.push(`[${name}] ${m.text().slice(0, 400)}`); });
    page.on("pageerror", (e) => errors.push(`[${name}] pageerror ${e.message}`));
    const url = `http://127.0.0.1:4102/harness/index.html?take=B&p=${p}&t=${t || 12}&dpr=${dprArg || 1}&overlay=${overlay}&q=${vp === "mob" ? "low" : "high"}`;
    const t0 = Date.now();
    await page.goto(url, { waitUntil: "load", timeout: 120000 });
    await page.waitForFunction(() => window.__ready === true, null, { timeout: 120000 });
    const info = await page.evaluate(() => ({ h: window.__horizon, info: window.__info, err: window.__error || null }));
    await page.screenshot({ path: path.join(OUT, `${name}.png`) });
    console.log(name, Date.now() - t0, "ms", JSON.stringify(info));
    await ctx.close();
  }
  if (errors.length) console.log("ERRORS:\n" + [...new Set(errors)].slice(0, 12).join("\n"));
  await browser.close();
  server.close();
})().catch((e) => { console.error(e); process.exit(1); });
