const { chromium } = require('playwright');
(async () => {
const OUT = process.argv[2];
const browser = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
const page = await ctx.newPage();
const logs = [];
page.on('console', m => logs.push(`[${m.type()}] ${m.text()}`));
page.on('pageerror', e => logs.push(`[pageerror] ${e.message}`));
await page.goto('https://gnbshipbrokers.com/', { waitUntil: 'networkidle', timeout: 60000 });
await page.waitForTimeout(3000);
await page.screenshot({ path: `${OUT}/d-00.png` });
const info = await page.evaluate(() => ({
  scrollH: document.documentElement.scrollHeight,
  innerH: innerHeight,
  track: (document.getElementById('track')||{}).offsetHeight,
  gl: (() => { const c = document.getElementById('gl'); return c ? { w: c.width, h: c.height, style: getComputedStyle(c).cssText?.slice(0,0), display: getComputedStyle(c).display, opacity: getComputedStyle(c).opacity } : null })(),
  rail: document.getElementById('rail')?.innerHTML.slice(0, 1500),
  fonts: [...document.fonts].map(f => f.family + ' ' + f.weight + ' ' + f.status).slice(0, 10),
  bodyBg: getComputedStyle(document.body).backgroundColor,
}));
console.log(JSON.stringify(info, null, 2));
const H = info.scrollH, step = Math.round(info.innerH * 0.5);
let i = 1;
for (let y = step; y <= H; y += step) {
  await page.mouse.wheel(0, step);
  await page.waitForTimeout(1400);
  await page.screenshot({ path: `${OUT}/d-${String(i).padStart(2, '0')}.png` });
  i++;
  if (i > 40) break;
}
console.log('desktop shots', i);
console.log(logs.slice(0, 30).join('\n'));
await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
