// Screenshot the LEVANTER homepage scene by scene.
// Usage: node shoot-site.cjs <baseUrl> <outDir> [path=/] [--mobile-only|--desktop-only] [--static]
const { chromium } = require("playwright");
const fs = require("fs");
const path = require("path");

const base = process.argv[2] || "http://127.0.0.1:3000";
const out = process.argv[3];
const pagePath = (process.argv.find((a) => a.startsWith("path=")) || "path=/").slice(5);
const mobileOnly = process.argv.includes("--mobile-only");
const desktopOnly = process.argv.includes("--desktop-only");
const staticMode = process.argv.includes("--static");
fs.mkdirSync(out, { recursive: true });

const IDS = ["overview", "desks", "why", "process", "team", "research", "faq", "contact"];

(async () => {
  const browser = await chromium.launch({
    args: ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"],
  });
  const vps = [
    ["desk", { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 }],
    ["mob", { viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true }],
  ].filter(([t]) => (mobileOnly ? t === "mob" : desktopOnly ? t === "desk" : true));
  const report = { errors: [], states: {} };
  for (const [tag, opts] of vps) {
    const ctx = await browser.newContext(opts);
    const page = await ctx.newPage();
    page.on("console", (m) => {
      if (m.type() === "error") report.errors.push(`[${tag}] ${m.text()}`);
    });
    page.on("pageerror", (e) => report.errors.push(`[${tag}] pageerror ${e.message}`));
    const url = `${base}${pagePath}${pagePath.includes("?") ? "&" : "?"}voyage=${staticMode ? 0 : 1}`;
    await page.goto(url, { waitUntil: "networkidle", timeout: 120000 });
    if (!staticMode) {
      await page
        .waitForSelector('.voyage-stage[data-state="live"]', { timeout: 60000 })
        .catch(() => report.errors.push(`[${tag}] stage never went live`));
    }
    await page.waitForTimeout(1500);
    for (const id of IDS) {
      const y = await page.evaluate((id) => {
        const el = document.getElementById(id);
        if (!el) return null;
        const r = el.getBoundingClientRect();
        const top = r.top + window.scrollY;
        const vh = window.innerHeight;
        if (id === "overview") return 0;
        return Math.max(0, top + Math.min(r.height, vh) / 2 - vh / 2);
      }, id);
      if (y == null) continue;
      await page.evaluate((y) => window.scrollTo({ top: y, behavior: "instant" }), y);
      await page.waitForTimeout(staticMode ? 1100 : 2600);
      await page.screenshot({ path: path.join(out, `${tag}-${id}.png`) });
      report.states[`${tag}-${id}`] = await page.evaluate(() => {
        const s = document.querySelector(".voyage-stage");
        return s ? `${s.getAttribute("data-state")}/${s.getAttribute("data-scene")}/${s.getAttribute("data-tone")}` : "none";
      });
    }
    await ctx.close();
  }
  fs.writeFileSync(path.join(out, "report.json"), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2).slice(0, 3000));
  await browser.close();
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
