const { chromium } = require("playwright");
(async () => {
  const [base, out, ...paths] = process.argv.slice(2);
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
  const p = await ctx.newPage();
  for (const path of paths) {
    await p.goto(base + path, { waitUntil: "networkidle" });
    await p.waitForTimeout(600);
    const name = path.replace(/\//g, "_") || "_root";
    await p.screenshot({ path: `${out}/page${name}.png`, fullPage: true });
  }
  await b.close();
})();
