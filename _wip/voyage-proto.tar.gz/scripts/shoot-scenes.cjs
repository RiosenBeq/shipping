const { chromium } = require('playwright');
(async () => {
  const OUT = process.argv[2];
  const browser = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const scenes = ['h','tanker-1','tanker-2','sharks','team','darussafaka','istanbul','dubai','contact'];
  for (const [tag, vp, extra] of [['desk', { width: 1440, height: 900 }, {}], ['mob', { width: 390, height: 844 }, { isMobile: true, hasTouch: true, deviceScaleFactor: 1 }]]) {
    const ctx = await browser.newContext({ viewport: vp, ...extra });
    const page = await ctx.newPage();
    await page.goto('https://gnbshipbrokers.com/', { waitUntil: 'networkidle', timeout: 60000 });
    await page.waitForTimeout(2500);
    for (const s of scenes) {
      const hash = s === 'contact' ? '#contact' : `#s-${s}`;
      await page.evaluate(h => { location.hash = h; }, hash);
      await page.waitForTimeout(3500);
      await page.screenshot({ path: `${OUT}/${tag}-${s}.png` });
    }
    // light/dark tone + key computed styles
    const css = await page.evaluate(() => {
      const pick = (sel, props) => { const el = document.querySelector(sel); if (!el) return null; const cs = getComputedStyle(el); return Object.fromEntries(props.map(p => [p, cs.getPropertyValue(p)])); };
      const P = ['font-family','font-size','font-weight','letter-spacing','line-height','color','text-transform'];
      return {
        hero: pick('.t-hero', P), statement: pick('.t-statement', P), display: pick('.t-display', P), sub: pick('.t-sub', P), lead: pick('.t-lead', P), label: pick('.t-label', P), data: pick('.t-data', P), h3: pick('.t-h3', P),
        chartTop: pick('.chart__top', ['top','left','right','height','background-color','opacity','border-top']),
        horizon: pick('.horizon__line', ['top','height','background-color','opacity']),
        grain: pick('.stage__grain', ['background-image','opacity','mix-blend-mode']),
        btn: pick('.hdr__cta', ['background-color','color','border-radius','padding','font-size','font-weight']),
        nav: pick('.hdr__nav', ['background-color','border-radius','padding','backdrop-filter']),
      };
    });
    console.log(tag, JSON.stringify(css, null, 1).slice(0, 4000));
    await ctx.close();
  }
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
